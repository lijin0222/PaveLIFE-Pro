# pavelife_core/pro_runner.py
"""PaveLIFE-Pro probabilistic workflow runner."""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from pavelife_core import legacy
from pavelife_core.config import default_analysis_settings, func_class_lookup
from pavelife_core.outputs import (
    build_layer_stage_table,
    build_parameter_documentation_df,
    build_pavement_type_config_df,
    build_phase_contribution_df,
    build_rate_metadata_df,
)
from pavelife_core.rate_prediction import build_single_section_dataframe
from pavelife_core.runner import apply_analysis_settings
from pavelife_core.schemas import validate_section_input
from pavelife_core.pro_bll import (
    BLLArtifacts,
    build_bll_feature_frame,
    load_bll_artifacts,
    predict_rate_log_samples,
    summarize_rate_predictions,
)
from pavelife_core.pro_iri import (
    build_single_sample_yearly_iri,
    process_section_probabilistic_iri,
)
from pavelife_core.lca import run_lca_single_section
from pavelife_core.lcca import run_lcca_single_section


PRO_MATERIAL_INPUT_DEFAULTS = {
    "no4_passing": 50.0,
    "no200_passing": 5.0,
    "air_voids": 4.0,
    "asphalt_content": 5.0,
    "vma": 15.0,
    "vfa": 70.0,
}


PRO_DEFAULT_SETTINGS = {
    "num_prediction_samples": 1000,
    "prediction_batch_size": 512,
    "rate_log_clip_lower": -8.0,
    "rate_log_clip_upper": 0.0,
    "num_life_cycle_samples": 200,
    "use_ppo_optimization": False,
    "ppo_total_timesteps": 20000,
    "ppo_seed": 42,
}


def build_pro_analysis_settings(analysis_settings: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    settings = default_analysis_settings.copy()
    settings.update(PRO_DEFAULT_SETTINGS)
    if analysis_settings:
        settings.update(analysis_settings)
    return settings


def validate_pro_input(input_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Validate base PaveLIFE input and append material variables."""
    validated = validate_section_input(input_dict)
    material_values = {}
    for key, default in PRO_MATERIAL_INPUT_DEFAULTS.items():
        value = input_dict.get(key, default)
        value = float(value)
        if value < 0.0:
            raise ValueError(f"{key} must be non-negative.")
        material_values[key] = value

    # Preserve snake_case keys for BLL feature construction.
    pro_input = dict(input_dict)
    pro_input.update(material_values)
    # Preserve notebook-style aliases for compatibility.
    pro_input.update({
        "SHRP_ID": validated["SHRP_ID"],
        "Pavement family": validated["Pavement family"],
        "Pavement type": validated["Pavement type"],
        "IRI0": validated["IRI0"],
        "Precipitation": validated["Precipitation"],
        "Temperature": validated["Temperature"],
        "Freeze index": validated["Freeze index"],
        "AADT": validated["AADT"],
        "AADTT": validated["AADTT"],
        "KESAL": validated["KESAL"],
        "Surface thickness": validated["Surface thickness"],
        "Base thickness": validated["Base thickness"],
        "Subbase thickness": validated["Subbase thickness"],
        "FUNC_CLASS": validated["FUNC_CLASS"],
    })
    return pro_input


def build_rate_prediction_df(
    df_input: pd.DataFrame,
    material_input: Dict[str, Any],
    rate_summary: pd.DataFrame,
    bll_artifacts: BLLArtifacts,
) -> pd.DataFrame:
    df_rate_pred = df_input.copy()
    for col in rate_summary.columns:
        df_rate_pred[col] = rate_summary[col].values

    df_rate_pred["prediction_model"] = "BLL probabilistic asphalt IRI rate model"
    df_rate_pred["rate_log_output"] = "posterior predictive distribution"
    df_rate_pred["thickness_input_unit"] = "m"
    df_rate_pred["thickness_model_unit"] = "inch"
    for key in PRO_MATERIAL_INPUT_DEFAULTS:
        df_rate_pred[key] = float(material_input.get(key, PRO_MATERIAL_INPUT_DEFAULTS[key]))

    return df_rate_pred


def summarize_distribution(df: pd.DataFrame, value_columns: Sequence[str]) -> pd.DataFrame:
    rows = []
    for col in value_columns:
        if col not in df.columns:
            continue
        values = pd.to_numeric(df[col], errors="coerce").dropna().to_numpy(dtype=float)
        if len(values) == 0:
            continue
        rows.append({
            "Metric": col,
            "mean": float(np.mean(values)),
            "std": float(np.std(values, ddof=0)),
            "p025": float(np.quantile(values, 0.025)),
            "p05": float(np.quantile(values, 0.05)),
            "p50": float(np.quantile(values, 0.50)),
            "p95": float(np.quantile(values, 0.95)),
            "p975": float(np.quantile(values, 0.975)),
        })
    return pd.DataFrame(rows)


def run_life_cycle_monte_carlo(
    row: pd.Series,
    rate_samples: Sequence[float],
    maintenance_years: Sequence[int],
    analysis_period_years: int,
    num_life_cycle_samples: int,
    seed: int = 42,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Run LCA/LCCA over sampled deterioration trajectories.

    The M&R schedule is taken from the reliability/PPO policy. Each Monte Carlo
    sample uses one posterior rate sample and its corresponding deterministic IRI
    trajectory under that schedule.
    """
    rng = np.random.default_rng(int(seed))
    rate_samples = np.asarray(rate_samples, dtype=np.float64)
    n_available = len(rate_samples)
    if n_available == 0:
        raise ValueError("No rate samples are available for life-cycle Monte Carlo.")

    n_samples = int(max(1, min(num_life_cycle_samples, n_available)))
    sample_indices = rng.choice(np.arange(n_available), size=n_samples, replace=(n_samples > n_available))

    lca_rows = []
    lcca_rows = []
    lca_event_frames = []
    lcca_event_frames = []

    shrp_id = str(row["SHRP_ID"])
    for mc_id, sample_idx in enumerate(sample_indices, start=1):
        rate_value = float(rate_samples[int(sample_idx)])
        df_yearly_sample = build_single_sample_yearly_iri(
            shrp_id=shrp_id,
            section_row=row,
            rate_value=rate_value,
            maintenance_years=maintenance_years,
            analysis_period_years=analysis_period_years,
        )
        lca_summary, lca_maintenance_events, _ = run_lca_single_section(row, df_yearly_sample, maintenance_years)
        lcca_summary, lcca_maintenance_events, _ = run_lcca_single_section(row, df_yearly_sample, maintenance_years)

        lca_row = lca_summary.iloc[0].to_dict()
        lca_row["mc_sample_id"] = mc_id
        lca_row["rate_sample"] = rate_value
        lca_rows.append(lca_row)

        lcca_row = lcca_summary.iloc[0].to_dict()
        lcca_row["mc_sample_id"] = mc_id
        lcca_row["rate_sample"] = rate_value
        lcca_rows.append(lcca_row)

        if isinstance(lca_maintenance_events, pd.DataFrame) and len(lca_maintenance_events) > 0:
            temp = lca_maintenance_events.copy()
            temp["mc_sample_id"] = mc_id
            lca_event_frames.append(temp)
        if isinstance(lcca_maintenance_events, pd.DataFrame) and len(lcca_maintenance_events) > 0:
            temp = lcca_maintenance_events.copy()
            temp["mc_sample_id"] = mc_id
            lcca_event_frames.append(temp)

    lca_distribution = pd.DataFrame(lca_rows)
    lcca_distribution = pd.DataFrame(lcca_rows)
    lca_events_distribution = pd.concat(lca_event_frames, ignore_index=True) if lca_event_frames else pd.DataFrame()
    lcca_events_distribution = pd.concat(lcca_event_frames, ignore_index=True) if lcca_event_frames else pd.DataFrame()
    return lca_distribution, lcca_distribution, lca_events_distribution, lcca_events_distribution


def mean_summary_from_distribution(distribution_df: pd.DataFrame, first_row_context: Optional[pd.Series] = None) -> pd.DataFrame:
    """Build a one-row mean summary preserving nonnumeric context where useful."""
    numeric_cols = distribution_df.select_dtypes(include=[np.number]).columns.tolist()
    numeric_cols = [c for c in numeric_cols if c not in ["mc_sample_id", "rate_sample"]]
    mean_values = {col: float(distribution_df[col].mean()) for col in numeric_cols}

    if first_row_context is not None:
        for col in ["SHRP_ID", "Maintenance Years"]:
            if col in distribution_df.columns:
                mean_values[col] = distribution_df[col].iloc[0]

    # Ensure expected total/count fields stay readable.
    if "Maintenance Count" in distribution_df.columns:
        mean_values["Maintenance Count"] = float(pd.to_numeric(distribution_df["Maintenance Count"], errors="coerce").mean())
    return pd.DataFrame([mean_values])


def build_pro_rate_metadata(bll_artifacts: BLLArtifacts, settings: Dict[str, Any]) -> pd.DataFrame:
    return pd.DataFrame([
        {"Parameter": "Model type", "Value": "Bayesian last-layer neural network", "Unit": "-"},
        {"Parameter": "Pavement family currently supported", "Value": "asphalt", "Unit": "-"},
        {"Parameter": "Scaler path", "Value": bll_artifacts.scaler_path, "Unit": "-"},
        {"Parameter": "Model package path", "Value": bll_artifacts.model_package_path, "Unit": "-"},
        {"Parameter": "Device", "Value": bll_artifacts.device, "Unit": "-"},
        {"Parameter": "Prediction samples", "Value": int(settings["num_prediction_samples"]), "Unit": "samples"},
        {"Parameter": "Lifecycle Monte Carlo samples", "Value": int(settings["num_life_cycle_samples"]), "Unit": "samples"},
        {"Parameter": "Feature columns", "Value": ", ".join(bll_artifacts.feature_columns), "Unit": "-"},
    ])


def build_reliability_mapping_df() -> pd.DataFrame:
    from pavelife_core.pro_iri import RELIABILITY_REQUIREMENT_BY_FUNC_CLASS
    rows = []
    for code, info in func_class_lookup.items():
        rows.append({
            "FUNC_CLASS": code,
            "FUNC_CLASS_EXP": info["FUNC_CLASS_EXP"],
            "IRI_threshold": info["IRI_threshold"],
            "Required reliability": RELIABILITY_REQUIREMENT_BY_FUNC_CLASS.get(code),
            "Car speed limit, km/h": info.get("car_speed_limit_kph"),
            "Truck speed limit, km/h": info.get("truck_speed_limit_kph"),
        })
    return pd.DataFrame(rows)


def run_pavelife_pro_single_section(
    input_dict: Dict[str, Any],
    analysis_settings: Optional[Dict[str, Any]] = None,
    model_dir: Optional[str] = None,
    bll_artifacts: Optional[BLLArtifacts] = None,
    output_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Run the PaveLIFE-Pro probabilistic workflow for one section/design."""
    settings = build_pro_analysis_settings(analysis_settings)
    apply_analysis_settings(analysis_settings=settings, output_dir=output_dir)

    pro_input = validate_pro_input(input_dict)
    pavement_family = str(pro_input["Pavement family"]).lower().strip()
    if pavement_family != "asphalt":
        raise NotImplementedError(
            "PaveLIFE-Pro currently supports probabilistic BLL IRI prediction for asphalt pavements only. "
            "Concrete functionality is preserved as a placeholder and can be enabled when the concrete BLL model is trained."
        )

    section_input_for_lifecycle = {
        "SHRP_ID": pro_input["SHRP_ID"],
        "Pavement family": pro_input["Pavement family"],
        "Pavement type": pro_input["Pavement type"],
        "IRI0": pro_input["IRI0"],
        "Precipitation": pro_input["Precipitation"],
        "Temperature": pro_input["Temperature"],
        "Freeze index": pro_input["Freeze index"],
        "AADT": pro_input["AADT"],
        "AADTT": pro_input["AADTT"],
        "KESAL": pro_input["KESAL"],
        "Surface thickness": pro_input["Surface thickness"],
        "Base thickness": pro_input["Base thickness"],
        "Subbase thickness": pro_input["Subbase thickness"],
        "FUNC_CLASS": pro_input["FUNC_CLASS"],
    }
    df_input = build_single_section_dataframe(section_input_for_lifecycle)

    if bll_artifacts is None:
        if model_dir is None:
            model_dir = os.path.join(os.getcwd(), "model_artifacts")
        bll_artifacts = load_bll_artifacts(model_dir=model_dir, pavement_family="asphalt")

    feature_df = build_bll_feature_frame(pro_input, bll_artifacts.feature_columns)
    rate_log_samples_by_row = predict_rate_log_samples(
        artifacts=bll_artifacts,
        feature_numeric_df=feature_df,
        num_samples=int(settings["num_prediction_samples"]),
        batch_size=int(settings["prediction_batch_size"]),
        include_noise=False,
    )
    rate_summary, rate_samples_by_row = summarize_rate_predictions(
        rate_log_samples_by_row,
        clip_lower=float(settings["rate_log_clip_lower"]),
        clip_upper=float(settings["rate_log_clip_upper"]),
    )
    rate_summary["SHRP_ID"] = df_input["SHRP_ID"].iloc[0]

    df_rate_pred = build_rate_prediction_df(
        df_input=df_input,
        material_input=pro_input,
        rate_summary=rate_summary,
        bll_artifacts=bll_artifacts,
    )

    row = df_rate_pred.iloc[0]
    rate_samples = rate_samples_by_row[0]

    forced_maintenance_years = None
    if bool(settings.get("use_ppo_optimization", False)):
        from pavelife_core.pro_ppo import run_project_level_ppo_policy
        forced_maintenance_years = run_project_level_ppo_policy(
            section_row=row,
            rate_samples=rate_samples,
            analysis_settings=settings,
        )

    df_yearly, maintenance_summary_df, maintenance_years = process_section_probabilistic_iri(
        shrp_id=str(row["SHRP_ID"]),
        section_row=row,
        rate_samples=rate_samples,
        analysis_period_years=int(settings["analysis_years"]),
        forced_maintenance_years=forced_maintenance_years,
    )

    # Probabilistic LCA/LCCA distribution.
    lca_distribution, lcca_distribution, lca_events_dist, lcca_events_dist = run_life_cycle_monte_carlo(
        row=row,
        rate_samples=rate_samples,
        maintenance_years=maintenance_years,
        analysis_period_years=int(settings["analysis_years"]),
        num_life_cycle_samples=int(settings["num_life_cycle_samples"]),
        seed=int(settings.get("ppo_seed", 42)),
    )

    lca_summary = mean_summary_from_distribution(lca_distribution, row)
    lcca_summary = mean_summary_from_distribution(lcca_distribution, row)

    # Retain the policy-driven maintenance summary and years in mean summaries.
    for summary_df in [lca_summary, lcca_summary]:
        summary_df["Maintenance Count"] = len(maintenance_years)
        summary_df["Maintenance Years"] = ", ".join(str(x) for x in maintenance_years)

    lca_phase_contribution = build_phase_contribution_df(
        summary_df=lca_summary,
        total_column="Total Emission",
        value_unit="kg CO2e",
    )
    lcca_phase_contribution = build_phase_contribution_df(
        summary_df=lcca_summary,
        total_column="Total Cost",
        value_unit=f"{int(settings['analysis_base_year'])} USD PV",
    )

    lca_layer_stage = build_layer_stage_table(lca_summary, "kg CO2e")
    lcca_layer_stage = build_layer_stage_table(lcca_summary, f"{int(settings['analysis_base_year'])} USD PV")

    lca_uncertainty_summary = summarize_distribution(lca_distribution, legacy.phase_columns + ["Total Emission"])
    lcca_uncertainty_summary = summarize_distribution(lcca_distribution, legacy.phase_columns + ["Total Cost"])

    parameter_documentation_df = build_parameter_documentation_df()
    pro_metadata_df = build_pro_rate_metadata(bll_artifacts, settings)
    func_class_mapping_df = build_reliability_mapping_df()
    pavement_type_config_df = build_pavement_type_config_df()

    results = {
        "input_parameters": df_input,
        "material_inputs": pd.DataFrame([{k: pro_input[k] for k in PRO_MATERIAL_INPUT_DEFAULTS}]),
        "bll_feature_input": feature_df,
        "rate_prediction": df_rate_pred,
        "rate_log_samples": pd.DataFrame(rate_log_samples_by_row[0], columns=["rate_log_sample"]),
        "rate_samples": pd.DataFrame(rate_samples, columns=["rate_sample"]),
        "yearly_iri": df_yearly,
        "maintenance_summary": maintenance_summary_df,
        "lca_summary": lca_summary,
        "lca_phase_contribution": lca_phase_contribution,
        "lca_layer_stage": lca_layer_stage,
        "lca_maintenance_events": lca_events_dist,
        "lca_eol_details": pd.DataFrame(),
        "lca_distribution": lca_distribution,
        "lca_uncertainty_summary": lca_uncertainty_summary,
        "lcca_summary": lcca_summary,
        "lcca_phase_contribution": lcca_phase_contribution,
        "lcca_layer_stage": lcca_layer_stage,
        "lcca_maintenance_events": lcca_events_dist,
        "lcca_eol_details": pd.DataFrame(),
        "lcca_distribution": lcca_distribution,
        "lcca_uncertainty_summary": lcca_uncertainty_summary,
        "parameter_documentation": parameter_documentation_df,
        "rate_model_metadata": pro_metadata_df,
        "func_class_mapping": func_class_mapping_df,
        "pavement_type_config": pavement_type_config_df,
        "figure_paths": {},
    }
    return results
