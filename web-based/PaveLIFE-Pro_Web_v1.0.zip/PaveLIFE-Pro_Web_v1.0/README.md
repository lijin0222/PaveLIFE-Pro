# PaveLIFE-Pro Web

PaveLIFE-Pro is an upgraded probabilistic Streamlit web tool built on top of PaveLIFE-Lite.
It adds Bayesian last-layer (BLL/BNN) probabilistic IRI deterioration-rate prediction,
reliability-based maintenance triggering, IRI-drop recovery, life-cycle Monte Carlo LCA/LCCA,
and an optional experimental PPO maintenance-policy hook.

## Current model support

- Asphalt probabilistic BLL IRI model: implemented.
- Concrete probabilistic BLL IRI model: placeholder retained for future model artifacts.
- Pavement type is still used by LCA/LCCA, but not by the BLL IRI model.

## Expected BLL artifact layout

Put the trained files exported from `BNN_last_layer_warm_start_v2.ipynb` under:

```text
model_artifacts/
└── probabilistic/
    └── asphalt/
        ├── iri_scaler_bll_v2.joblib
        ├── iri_model_package_bll_v2.pt
        └── <pyro parameter-store file referenced by iri_model_package_bll_v2.pt>
```

The `.pt` package must contain at least: `input_dim`, `best_params`, `model_state_dict`,
`y_mean_final`, `y_std_final`, and `pyro_param_path`.

## Running in the MI environment

```bash
conda activate MI
cd path/to/PaveLIFE_Pro_Web
python -m streamlit run app.py
```

Install additional probabilistic-model dependencies if needed:

```bash
pip install torch pyro-ppl plotly
```

The optional PPO policy requires:

```bash
pip install gymnasium stable-baselines3
```

## Main changes from PaveLIFE-Lite

1. Rate prediction is probabilistic: `Rate_Log` posterior predictive samples are generated.
2. Material inputs are added: NO. 4 passing 1/2, air voids, asphalt content, VMA 1/2, and VFA.
3. M&R is triggered by reliability: `P(IRI < threshold)` must exceed the required functional-class reliability.
4. The reliability requirements for FUNC_CLASS 1–8 are: 95%, 90%, 80%, 75%, 95%, 85%, 75%, and 70%.
5. Post-maintenance IRI is updated using the IRI-drop model `drop = 0.7934*IRI_before - 0.5457`, bounded below by IRI0.
6. LCA/LCCA are calculated as probability distributions using Monte Carlo samples; contribution rates use mean phase values.
