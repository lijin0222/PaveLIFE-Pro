# pavelife_core/pro_bll.py
"""Probabilistic BLL/BNN rate-log prediction utilities for PaveLIFE-Pro.

This module is intentionally self-contained and lazy-imports torch/pyro so that
PaveLIFE-Lite functionality remains importable even when probabilistic-model
packages are not installed.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import joblib
import numpy as np
import pandas as pd


# Authoritative fixed input feature order for the asphalt BLL model trained in
# BNN_last_layer_warm_start_v2.ipynb. The web tool always uses this exact order,
# regardless of whether the exported model package or scaler contains feature
# names. Thickness features are entered in meters in the UI but converted to
# inches here before BLL prediction, because the model was trained with inch
# thickness inputs.
DEFAULT_BLL_FEATURE_COLUMNS_16 = [
    "IRI0",
    "Precipitation",
    "Temperature",
    "Freeze index",
    "AADT",
    "AADTT",
    "KESAL",
    "Subbase thickness",
    "Base thickness",
    "Asphalt thickness",
    "NO. 4 passing",
    "NO. 200 passing",
    "Air voids",
    "Asphalt content",
    "VMA",
    "VFA",
]

# Backward-compatible alias used elsewhere in this module.
DEFAULT_BLL_FEATURE_COLUMNS = list(DEFAULT_BLL_FEATURE_COLUMNS_16)



@dataclass
class BLLArtifacts:
    scaler: Any
    model_package: Dict[str, Any]
    model: Any
    guide: Any
    y_mean: float
    y_std: float
    feature_columns: List[str]
    scaler_path: str
    model_package_path: str
    device: str


class ProbabilisticModelNotAvailableError(RuntimeError):
    """Raised when the probabilistic BLL model cannot be used."""


# -------------------------
# Optional dependency helpers
# -------------------------
def _import_bll_dependencies():
    try:
        import torch
        from torch import nn
        import pyro
        import pyro.distributions as dist
        import pyro.nn as pnn
        from pyro.infer import Predictive
        from pyro.infer.autoguide import AutoDiagonalNormal
        from torch.distributions import constraints
    except Exception as exc:  # pragma: no cover - environment-dependent
        raise ProbabilisticModelNotAvailableError(
            "PaveLIFE-Pro probabilistic BLL prediction requires torch and pyro-ppl. "
            "Install them in the active environment, for example: pip install torch pyro-ppl"
        ) from exc

    return torch, nn, pyro, dist, pnn, Predictive, AutoDiagonalNormal, constraints


def _build_bayesian_nn_class(torch, nn, pyro, dist, pnn, constraints):
    class bayesian_nn(pnn.PyroModule):
        """Last-layer Bayesian neural network consistent with the training notebook."""

        def __init__(self, input_dim, hidden_units=(64, 64), prior_scale=1.0):
            super().__init__()

            if isinstance(hidden_units, int):
                hidden_units_local = (hidden_units,)
            elif isinstance(hidden_units, list):
                hidden_units_local = tuple(hidden_units)
            else:
                hidden_units_local = hidden_units

            self.layer_names = []
            prev_dim = int(input_dim)

            for i, units in enumerate(hidden_units_local):
                units = int(units)
                layer = pnn.PyroModule[nn.Linear](prev_dim, units)
                name = f"fc{i}"
                setattr(self, name, layer)
                self.layer_names.append(name)
                prev_dim = units

            weight_std_out = float(prior_scale) / np.sqrt(max(1, prev_dim))

            self.out = pnn.PyroModule[nn.Linear](prev_dim, 1)
            self.out.weight = pnn.PyroSample(
                dist.Normal(0.0, weight_std_out).expand([1, prev_dim]).to_event(2)
            )
            self.out.bias = pnn.PyroSample(
                dist.Normal(0.0, float(prior_scale)).expand([1]).to_event(1)
            )

        def forward(self, x, y=None, batch_size=None):
            obs_sigma = pyro.param(
                "obs_sigma",
                torch.tensor(1.0, device=x.device),
                constraint=constraints.positive,
            )

            n_total = int(x.shape[0])

            if y is None:
                h = x
                for name in self.layer_names:
                    h = torch.relu(getattr(self, name)(h))
                mean = self.out(h).squeeze(-1)
                with pyro.plate("data", n_total):
                    pyro.sample("obs", dist.Normal(mean, obs_sigma), obs=None)
                return mean

            if batch_size is None:
                batch_size = n_total
            batch_size = int(min(max(1, batch_size), n_total))

            if batch_size == n_total:
                ind = torch.arange(n_total, device=x.device)
            else:
                ind = torch.randperm(n_total, device=x.device)[:batch_size]

            x_b = x[ind]
            y_b = y[ind]

            h_b = x_b
            for name in self.layer_names:
                h_b = torch.relu(getattr(self, name)(h_b))
            mean_b = self.out(h_b).squeeze(-1)

            with pyro.plate("data", size=n_total, subsample=ind):
                pyro.sample("obs", dist.Normal(mean_b, obs_sigma), obs=y_b)

            return mean_b

    return bayesian_nn


def safe_torch_load(file_path: str, map_location: Any):
    torch, *_ = _import_bll_dependencies()
    try:
        return torch.load(file_path, map_location=map_location, weights_only=False)
    except TypeError:  # pragma: no cover - older torch
        return torch.load(file_path, map_location=map_location)


def destandardize_y(y_np_std: np.ndarray, y_mean: float, y_std: float) -> np.ndarray:
    return (y_np_std * float(y_std) + float(y_mean)).astype(np.float32)


# -------------------------
# Artifact loading
# -------------------------
def find_default_bll_paths(model_dir: str, pavement_family: str = "asphalt") -> Dict[str, str]:
    """Return expected BLL artifact paths.

    The current PaveLIFE-Pro release only has an asphalt BLL model. Concrete paths
    are still returned as future placeholders.
    """
    pavement_family = str(pavement_family).lower().strip()
    subdir = os.path.join(model_dir, "probabilistic", pavement_family)

    if pavement_family == "asphalt":
        return {
            "scaler_path": os.path.join(subdir, "iri_scaler_bll_v2.joblib"),
            "model_package_path": os.path.join(subdir, "iri_model_package_bll_v2.pt"),
        }

    return {
        "scaler_path": os.path.join(subdir, "iri_scaler_bll_v2.joblib"),
        "model_package_path": os.path.join(subdir, "iri_model_package_bll_v2.pt"),
    }


def _looks_like_placeholder_feature_names(columns: Sequence[str]) -> bool:
    """Return True for generated names such as feature_0 ... feature_15."""
    cols = [str(c).strip().lower() for c in list(columns)]
    if not cols:
        return False
    return all(col == f"feature_{i}" for i, col in enumerate(cols))


def _fallback_feature_columns_for_input_dim(input_dim: int) -> List[str]:
    """Return the best-known feature order for a given BLL input dimension."""
    input_dim = int(input_dim)
    if input_dim == len(DEFAULT_BLL_FEATURE_COLUMNS_16):
        return list(DEFAULT_BLL_FEATURE_COLUMNS_16)
    if input_dim == len(DEFAULT_BLL_FEATURE_COLUMNS):
        return list(DEFAULT_BLL_FEATURE_COLUMNS)
    return [f"feature_{i}" for i in range(input_dim)]


def infer_feature_columns_from_artifacts(scaler: Any, pkg: Dict[str, Any]) -> List[str]:
    """Return the fixed 16-feature asphalt BLL input order.

    This deliberately ignores feature names stored in the model package or scaler.
    The current PaveLIFE-Pro asphalt BLL model is defined by the following exact
    16 inputs:

    1. IRI0
    2. Precipitation
    3. Temperature
    4. Freeze index
    5. AADT
    6. AADTT
    7. KESAL
    8. Subbase thickness
    9. Base thickness
    10. Asphalt thickness
    11. NO. 4 passing
    12. NO. 200 passing
    13. Air voids
    14. Asphalt content
    15. VMA
    16. VFA
    """
    input_dim = int(pkg.get("input_dim", len(DEFAULT_BLL_FEATURE_COLUMNS_16)))
    if input_dim != len(DEFAULT_BLL_FEATURE_COLUMNS_16):
        raise ValueError(
            f"The current fixed asphalt BLL feature order requires input_dim "
            f"{len(DEFAULT_BLL_FEATURE_COLUMNS_16)}, but the loaded model package "
            f"reports input_dim={input_dim}. Please check that the correct BLL model "
            "artifact is being used."
        )
    return list(DEFAULT_BLL_FEATURE_COLUMNS_16)


def load_bll_artifacts(
    model_dir: str,
    pavement_family: str = "asphalt",
    device: Optional[str] = None,
) -> BLLArtifacts:
    """Load scaler, BLL model package, Pyro guide, and feature metadata."""
    pavement_family = str(pavement_family).lower().strip()
    if pavement_family != "asphalt":
        raise NotImplementedError(
            "PaveLIFE-Pro currently includes only the asphalt probabilistic BLL IRI model. "
            "Concrete probabilistic prediction is reserved as a future placeholder."
        )

    paths = find_default_bll_paths(model_dir, pavement_family=pavement_family)
    scaler_path = paths["scaler_path"]
    model_package_path = paths["model_package_path"]

    missing = [p for p in [scaler_path, model_package_path] if not os.path.exists(p)]
    if missing:
        raise FileNotFoundError(
            "Missing PaveLIFE-Pro BLL model artifact(s):\n"
            + "\n".join(missing)
            + "\n\nExpected folder layout:\n"
            + "model_artifacts/probabilistic/asphalt/iri_scaler_bll_v2.joblib\n"
            + "model_artifacts/probabilistic/asphalt/iri_model_package_bll_v2.pt\n"
            + "plus the Pyro parameter-store file referenced inside the .pt package."
        )

    torch, nn, pyro, dist, pnn, Predictive, AutoDiagonalNormal, constraints = _import_bll_dependencies()
    target_device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))

    scaler_loaded = joblib.load(scaler_path)
    pkg = safe_torch_load(model_package_path, map_location="cpu")

    input_dim = int(pkg["input_dim"])
    best_params = pkg["best_params"]
    y_mean_final = float(pkg["y_mean_final"])
    y_std_final = float(pkg["y_std_final"])

    pyro.clear_param_store()
    bayesian_nn = _build_bayesian_nn_class(torch, nn, pyro, dist, pnn, constraints)
    model_loaded = bayesian_nn(
        input_dim=input_dim,
        hidden_units=best_params["hidden_units"],
        prior_scale=best_params["prior_scale"],
    ).to(target_device)
    model_loaded.load_state_dict(pkg["model_state_dict"], strict=False)

    guide_loaded = AutoDiagonalNormal(pyro.poutine.block(model_loaded, hide=["obs"]))

    pyro_param_path = pkg.get("pyro_param_path")
    if pyro_param_path is None:
        raise FileNotFoundError(
            "The BLL model package does not contain 'pyro_param_path'. Please check the training export."
        )

    if not os.path.exists(pyro_param_path):
        model_pkg_dir = os.path.dirname(os.path.abspath(model_package_path))
        candidate = os.path.join(model_pkg_dir, os.path.basename(pyro_param_path))
        if os.path.exists(candidate):
            pyro_param_path = candidate

    if not os.path.exists(pyro_param_path):
        raise FileNotFoundError(
            "Missing Pyro parameter-store file referenced by the BLL model package:\n"
            f"{pyro_param_path}\n"
            "Put this file in the same folder as iri_model_package_bll_v2.pt, or update the package path."
        )

    param_state = safe_torch_load(pyro_param_path, map_location=target_device)
    if isinstance(param_state, dict) and "params" in param_state:
        for key in list(param_state["params"].keys()):
            param_state["params"][key] = param_state["params"][key].to(target_device)
    pyro.get_param_store().set_state(param_state)

    feature_columns = infer_feature_columns_from_artifacts(scaler_loaded, pkg)
    if len(feature_columns) != input_dim:
        raise ValueError(
            f"BLL feature-column count ({len(feature_columns)}) does not match input_dim ({input_dim}). "
            "Store the correct feature list in the model package or fit the scaler with DataFrame columns."
        )

    return BLLArtifacts(
        scaler=scaler_loaded,
        model_package=pkg,
        model=model_loaded,
        guide=guide_loaded,
        y_mean=y_mean_final,
        y_std=y_std_final,
        feature_columns=feature_columns,
        scaler_path=scaler_path,
        model_package_path=model_package_path,
        device=str(target_device),
    )


# -------------------------
# Feature construction
# -------------------------
def normalize_feature_name(value: str) -> str:
    """Normalize feature names from UI, Excel headers, and model metadata."""
    text = str(value).strip().lower()
    replacements = [
        ("_", " "),
        ("-", " "),
        ("#", "no "),
        ("%", " "),
        ("/", " "),
        ("(", " "),
        (")", " "),
        (":", " "),
        (".", " "),
    ]
    for old, new in replacements:
        text = text.replace(old, new)
    text = " ".join(text.split())
    return text


def build_feature_value_lookup(input_dict: Dict[str, Any]) -> Dict[str, float]:
    """Create normalized feature lookup for the fixed 16-feature asphalt BLL model.

    User-facing thicknesses are entered in meters. Only the BLL feature copy is
    converted to inches. LCA/LCCA continue to use the original meter inputs.
    """
    surface_m = float(input_dict.get("surface_thickness", input_dict.get("Surface thickness", 0.0)))
    base_m = float(input_dict.get("base_thickness", input_dict.get("Base thickness", 0.0)))
    subbase_m = float(input_dict.get("subbase_thickness", input_dict.get("Subbase thickness", 0.0)))
    meter_to_inch = 1.0 / 0.0254

    values = {
        "IRI0": input_dict.get("iri0", input_dict.get("IRI0", 0.0)),
        "Precipitation": input_dict.get("precipitation", input_dict.get("Precipitation", 0.0)),
        "Temperature": input_dict.get("temperature", input_dict.get("Temperature", 0.0)),
        "Freeze index": input_dict.get("freeze_index", input_dict.get("Freeze index", 0.0)),
        "AADT": input_dict.get("aadt", input_dict.get("AADT", 0.0)),
        "AADTT": input_dict.get("aadtt", input_dict.get("AADTT", 0.0)),
        "KESAL": input_dict.get("kesal", input_dict.get("KESAL", 0.0)),
        "Subbase thickness": subbase_m * meter_to_inch,
        "Base thickness": base_m * meter_to_inch,
        "Asphalt thickness": surface_m * meter_to_inch,
        "NO. 4 passing": input_dict.get("no4_passing", input_dict.get("NO. 4 passing", 50.0)),
        "NO. 200 passing": input_dict.get("no200_passing", input_dict.get("NO. 200 passing", 5.0)),
        "Air voids": input_dict.get("air_voids", input_dict.get("Air voids", 4.0)),
        "Asphalt content": input_dict.get("asphalt_content", input_dict.get("Asphalt content", 5.0)),
        "VMA": input_dict.get("vma", input_dict.get("VMA", 15.0)),
        "VFA": input_dict.get("vfa", input_dict.get("VFA", 70.0)),
    }

    return {normalize_feature_name(k): float(v) for k, v in values.items() if _is_float_like(v)}


def _is_float_like(value: Any) -> bool:
    try:
        float(value)
        return True
    except Exception:
        return False


def resolve_runtime_feature_columns(feature_columns: Sequence[str]) -> List[str]:
    """Return the fixed 16-feature asphalt BLL order.

    The argument is accepted only for API compatibility with existing calls.
    """
    if len(list(feature_columns)) != len(DEFAULT_BLL_FEATURE_COLUMNS_16):
        raise ValueError(
            f"The loaded BLL artifacts expose {len(list(feature_columns))} input features, "
            f"but PaveLIFE-Pro is configured for exactly {len(DEFAULT_BLL_FEATURE_COLUMNS_16)} fixed features."
        )
    return list(DEFAULT_BLL_FEATURE_COLUMNS_16)

def build_bll_feature_frame(input_dict: Dict[str, Any], feature_columns: Sequence[str]) -> pd.DataFrame:
    """Build a one-row numeric feature DataFrame aligned with BLL feature order."""
    runtime_feature_columns = resolve_runtime_feature_columns(feature_columns)
    lookup = build_feature_value_lookup(input_dict)
    duplicate_counter: Dict[str, int] = {}
    values: List[float] = []
    missing: List[str] = []

    for col in runtime_feature_columns:
        norm = normalize_feature_name(col)
        duplicate_counter[norm] = duplicate_counter.get(norm, 0) + 1
        if duplicate_counter[norm] > 1:
            duplicate_key = f"{norm}__{duplicate_counter[norm]}"
            if duplicate_key in lookup:
                values.append(float(lookup[duplicate_key]))
                continue

        if norm in lookup:
            values.append(float(lookup[norm]))
        else:
            missing.append(str(col))
            values.append(np.nan)

    df = pd.DataFrame([values], columns=[str(c) for c in runtime_feature_columns])
    if missing:
        available = sorted(build_feature_value_lookup(input_dict).keys())
        raise ValueError(
            "PaveLIFE-Pro could not build all BLL input features. Missing feature(s): "
            f"{missing}. Available normalized UI feature keys include: {available}. "
            "The asphalt BLL feature order is fixed in DEFAULT_BLL_FEATURE_COLUMNS_16 in pro_bll.py."
        )
    return df.apply(pd.to_numeric, errors="coerce")


# -------------------------
# Prediction and summaries
# -------------------------
def predict_rate_log_samples(
    artifacts: BLLArtifacts,
    feature_numeric_df: pd.DataFrame,
    num_samples: int = 1000,
    batch_size: int = 512,
    include_noise: bool = False,
) -> np.ndarray:
    """Generate posterior predictive rate_log samples, shape [n_rows, num_samples]."""
    torch, nn, pyro, dist, pnn, Predictive, AutoDiagonalNormal, constraints = _import_bll_dependencies()
    x_raw = feature_numeric_df.values.astype(np.float32)
    n_rows = x_raw.shape[0]
    batch_size = int(min(max(1, batch_size), n_rows))

    sample_batches = []
    target_device = torch.device(artifacts.device)
    t_start = time.time()

    for start_idx in range(0, n_rows, batch_size):
        end_idx = min(start_idx + batch_size, n_rows)
        x_batch_raw = x_raw[start_idx:end_idx]
        x_batch_scaled = artifacts.scaler.transform(x_batch_raw).astype(np.float32)
        x_batch_t = torch.from_numpy(x_batch_scaled).to(target_device)

        return_sites = ("_RETURN", "obs") if include_noise else ("_RETURN",)
        predictive = Predictive(
            artifacts.model,
            guide=artifacts.guide,
            num_samples=int(num_samples),
            return_sites=return_sites,
        )

        with torch.no_grad():
            out = predictive(x_batch_t)

        if include_noise:
            batch_samples_std = out["obs"].detach().cpu().numpy()
        else:
            batch_samples_std = out["_RETURN"].detach().cpu().numpy()

        batch_samples = destandardize_y(batch_samples_std, artifacts.y_mean, artifacts.y_std)
        sample_batches.append(batch_samples.T.astype(np.float64))

    rate_log_samples_by_row = np.vstack(sample_batches)
    _ = time.time() - t_start
    return rate_log_samples_by_row


def summarize_rate_predictions(rate_log_samples_by_row: np.ndarray, clip_lower: float = -8.0, clip_upper: float = 0.0) -> Tuple[pd.DataFrame, np.ndarray]:
    """Summarize rate_log and rate samples."""
    rate_log_samples_by_row = np.asarray(rate_log_samples_by_row, dtype=np.float64)
    rate_log_for_rate = np.clip(rate_log_samples_by_row, clip_lower, clip_upper)
    rate_samples_by_row = np.power(10.0, rate_log_for_rate)

    summary_df = pd.DataFrame({
        "row_index": np.arange(rate_log_samples_by_row.shape[0]),
        "rate_log_mean": np.mean(rate_log_samples_by_row, axis=1),
        "rate_log_std": np.std(rate_log_samples_by_row, axis=1, ddof=0),
        "rate_log_p025": np.quantile(rate_log_samples_by_row, 0.025, axis=1),
        "rate_log_p05": np.quantile(rate_log_samples_by_row, 0.05, axis=1),
        "rate_log_p50": np.quantile(rate_log_samples_by_row, 0.50, axis=1),
        "rate_log_p95": np.quantile(rate_log_samples_by_row, 0.95, axis=1),
        "rate_log_p975": np.quantile(rate_log_samples_by_row, 0.975, axis=1),
        "rate_mean": np.mean(rate_samples_by_row, axis=1),
        "rate_std": np.std(rate_samples_by_row, axis=1, ddof=0),
        "rate_p025": np.quantile(rate_samples_by_row, 0.025, axis=1),
        "rate_p05": np.quantile(rate_samples_by_row, 0.05, axis=1),
        "rate_p50": np.quantile(rate_samples_by_row, 0.50, axis=1),
        "rate_p95": np.quantile(rate_samples_by_row, 0.95, axis=1),
        "rate_p975": np.quantile(rate_samples_by_row, 0.975, axis=1),
    })

    # Backward-compatible columns used by Lite metric cards.
    summary_df["rate_log_pred"] = summary_df["rate_log_mean"]
    summary_df["rate_pred"] = summary_df["rate_mean"]
    return summary_df, rate_samples_by_row
