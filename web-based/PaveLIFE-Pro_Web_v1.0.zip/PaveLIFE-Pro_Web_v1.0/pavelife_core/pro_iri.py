# pavelife_core/pro_iri.py
"""Reliability-based probabilistic IRI and M&R logic for PaveLIFE-Pro."""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from pavelife_core.config import func_class_lookup


RELIABILITY_REQUIREMENT_BY_FUNC_CLASS = {
    1: 0.95,
    2: 0.90,
    3: 0.80,
    4: 0.75,
    5: 0.95,
    6: 0.85,
    7: 0.75,
    8: 0.70,
}


def calculate_threshold(func_class: int) -> float:
    """Return the IRI service threshold for the current 1-8 functional-class mapping."""
    func_class = int(func_class)
    if func_class not in func_class_lookup:
        raise ValueError("FUNC_CLASS must be one of 1, 2, ..., 8.")
    return float(func_class_lookup[func_class]["IRI_threshold"])


def calculate_reliability_requirement(func_class: int) -> float:
    """Return required P(IRI < threshold) for the current 1-8 mapping."""
    return float(RELIABILITY_REQUIREMENT_BY_FUNC_CLASS.get(int(func_class), 0.75))


def calculate_iri_drop(iri_before_maintenance, a: float = 0.7934, b: float = -0.5457):
    """Calculate probabilistic IRI drop using y = a*x + b."""
    iri_before_array = np.asarray(iri_before_maintenance, dtype=np.float64)
    iri_drop = float(a) * iri_before_array + float(b)
    if np.isscalar(iri_before_maintenance):
        return float(iri_drop)
    return iri_drop


def summarize_samples(samples: Sequence[float]) -> Dict[str, float]:
    arr = np.asarray(samples, dtype=np.float64)
    return {
        "mean": float(np.mean(arr)),
        "std": float(np.std(arr, ddof=0)),
        "p025": float(np.quantile(arr, 0.025)),
        "p05": float(np.quantile(arr, 0.05)),
        "p50": float(np.quantile(arr, 0.50)),
        "p95": float(np.quantile(arr, 0.95)),
        "p975": float(np.quantile(arr, 0.975)),
    }


def process_section_probabilistic_iri(
    shrp_id: str,
    section_row: pd.Series,
    rate_samples: Sequence[float],
    analysis_period_years: int = 50,
    forced_maintenance_years: Optional[Iterable[int]] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame, List[int]]:
    """Predict probabilistic IRI progression and trigger M&R by reliability.

    Reliability is defined as P(IRI < IRI_threshold). M&R is triggered when
    reliability falls below the functional-class-specific requirement. A set of
    forced maintenance years can be supplied by an external optimizer such as PPO.
    """
    if "IRI0" not in section_row.index:
        raise ValueError("section_row is missing IRI0.")
    if "FUNC_CLASS" not in section_row.index:
        raise ValueError("section_row is missing FUNC_CLASS.")

    iri0 = float(section_row["IRI0"])
    func_class = int(section_row["FUNC_CLASS"])
    iri_threshold = calculate_threshold(func_class)
    required_reliability = calculate_reliability_requirement(func_class)
    rate_samples = np.maximum(np.asarray(rate_samples, dtype=np.float64), 0.0)

    forced_set = set(int(x) for x in forced_maintenance_years) if forced_maintenance_years is not None else set()

    yearly_records = []
    maintenance_years: List[int] = []
    last_maintenance_year = 0
    cycle_start_iri_samples = np.full_like(rate_samples, iri0, dtype=np.float64)

    for pavement_age in range(0, int(analysis_period_years) + 1):
        age_since_last_maintenance = pavement_age - last_maintenance_year

        if pavement_age == 0:
            iri_samples_before = cycle_start_iri_samples.copy()
        else:
            exp_arg = np.clip(rate_samples * float(age_since_last_maintenance), -50.0, 50.0)
            iri_samples_before = cycle_start_iri_samples * np.exp(exp_arg)

        iri_before_stats = summarize_samples(iri_samples_before)
        reliability_before = float(np.mean(iri_samples_before < iri_threshold))

        maintenance_flag = 0
        maintenance_reason = ""
        if pavement_age > 0:
            if pavement_age in forced_set:
                maintenance_flag = 1
                maintenance_reason = "ppo_forced_maintenance"
            elif reliability_before < required_reliability:
                maintenance_flag = 1
                maintenance_reason = "reliability_below_requirement"

        iri_drop_samples = np.zeros_like(rate_samples, dtype=np.float64)
        raw_iri_samples_after = iri_samples_before.copy()
        iri_samples_after = iri_samples_before.copy()
        iri_after_lower_bound_share = 0.0

        if maintenance_flag == 1:
            maintenance_years.append(pavement_age)
            iri_drop_samples = calculate_iri_drop(iri_samples_before)
            raw_iri_samples_after = iri_samples_before - iri_drop_samples
            iri_samples_after = np.maximum(raw_iri_samples_after, iri0)
            iri_after_lower_bound_share = float(np.mean(raw_iri_samples_after < iri0))
            cycle_start_iri_samples = iri_samples_after.copy()
            last_maintenance_year = pavement_age

        iri_after_stats = summarize_samples(iri_samples_after)
        iri_drop_stats = summarize_samples(iri_drop_samples)
        reliability_after = float(np.mean(iri_samples_after < iri_threshold))

        yearly_records.append({
            "SHRP_ID": shrp_id,
            "FUNC_CLASS": func_class,
            "IRI_threshold": iri_threshold,
            "Required_reliability": required_reliability,
            "Pavement_Age": pavement_age,
            "Age_since_last_maintenance": age_since_last_maintenance,
            "Reliability_before_maintenance": reliability_before,
            "Reliability_after_maintenance": reliability_after,
            "maintenance_flag": maintenance_flag,
            "maintenance_reason": maintenance_reason,
            "IRI_pred_before_maintenance": iri_before_stats["mean"],
            "IRI_before_std": iri_before_stats["std"],
            "IRI_before_p025": iri_before_stats["p025"],
            "IRI_before_p05": iri_before_stats["p05"],
            "IRI_before_p50": iri_before_stats["p50"],
            "IRI_before_p95": iri_before_stats["p95"],
            "IRI_before_p975": iri_before_stats["p975"],
            "IRI_drop_mean": iri_drop_stats["mean"],
            "IRI_drop_p50": iri_drop_stats["p50"],
            "IRI_drop_p95": iri_drop_stats["p95"],
            "Raw_IRI_after_mean": float(np.mean(raw_iri_samples_after)),
            "IRI_after_lower_bound_share": iri_after_lower_bound_share,
            "IRI_pred": iri_after_stats["mean"],
            "IRI_after_std": iri_after_stats["std"],
            "IRI_after_p025": iri_after_stats["p025"],
            "IRI_after_p05": iri_after_stats["p05"],
            "IRI_after_p50": iri_after_stats["p50"],
            "IRI_after_p95": iri_after_stats["p95"],
            "IRI_after_p975": iri_after_stats["p975"],
        })

    df_yearly = pd.DataFrame(yearly_records)
    summary = pd.DataFrame([{
        "SHRP_ID": shrp_id,
        "FUNC_CLASS": func_class,
        "IRI_threshold": iri_threshold,
        "Required_reliability": required_reliability,
        "initial_IRI0": iri0,
        "rate_mean": float(np.mean(rate_samples)),
        "rate_std": float(np.std(rate_samples, ddof=0)),
        "rate_p05": float(np.quantile(rate_samples, 0.05)),
        "rate_p50": float(np.quantile(rate_samples, 0.50)),
        "rate_p95": float(np.quantile(rate_samples, 0.95)),
        "maintenance_count": len(maintenance_years),
        "maintenance_years": ", ".join(str(y) for y in maintenance_years),
        "minimum_reliability_over_analysis_period": float(df_yearly["Reliability_before_maintenance"].min()),
    }])
    return df_yearly, summary, maintenance_years


def build_single_sample_yearly_iri(
    shrp_id: str,
    section_row: pd.Series,
    rate_value: float,
    maintenance_years: Sequence[int],
    analysis_period_years: int = 50,
) -> pd.DataFrame:
    """Build a deterministic yearly IRI path for one posterior rate sample.

    The M&R schedule is held fixed at the reliability/PPO-derived schedule. This
    makes Monte Carlo LCA/LCCA computationally tractable while preserving the
    probabilistic deterioration trajectory.
    """
    iri0 = float(section_row["IRI0"])
    func_class = int(section_row["FUNC_CLASS"])
    iri_threshold = calculate_threshold(func_class)
    required_reliability = calculate_reliability_requirement(func_class)
    rate_value = max(float(rate_value), 0.0)
    mr_set = set(int(y) for y in maintenance_years)

    rows = []
    cycle_start_iri = iri0
    last_maintenance_year = 0

    for pavement_age in range(0, int(analysis_period_years) + 1):
        age_since_last_maintenance = pavement_age - last_maintenance_year
        if pavement_age == 0:
            iri_before = cycle_start_iri
        else:
            iri_before = cycle_start_iri * np.exp(np.clip(rate_value * float(age_since_last_maintenance), -50.0, 50.0))

        maintenance_flag = 1 if pavement_age in mr_set else 0
        iri_drop = 0.0
        iri_after = iri_before
        if maintenance_flag:
            iri_drop = calculate_iri_drop(iri_before)
            iri_after = max(iri_before - iri_drop, iri0)
            cycle_start_iri = iri_after
            last_maintenance_year = pavement_age

        rows.append({
            "SHRP_ID": shrp_id,
            "FUNC_CLASS": func_class,
            "IRI_threshold": iri_threshold,
            "Required_reliability": required_reliability,
            "Pavement_Age": pavement_age,
            "Age_since_last_maintenance": age_since_last_maintenance,
            "Reliability_before_maintenance": np.nan,
            "Reliability_after_maintenance": np.nan,
            "maintenance_flag": maintenance_flag,
            "maintenance_reason": "fixed_from_reliability_or_ppo" if maintenance_flag else "",
            "IRI_pred_before_maintenance": float(iri_before),
            "IRI_before_p50": float(iri_before),
            "IRI_before_p05": float(iri_before),
            "IRI_before_p95": float(iri_before),
            "IRI_pred": float(iri_after),
            "IRI_after_p50": float(iri_after),
            "IRI_after_p05": float(iri_after),
            "IRI_after_p95": float(iri_after),
            "IRI_drop_mean": float(iri_drop),
        })

    return pd.DataFrame(rows)
