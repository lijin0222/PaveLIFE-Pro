# app.py

import os
from io import BytesIO

import pandas as pd
import streamlit as st

try:
    import plotly.graph_objects as go
except Exception:
    go = None

from pavelife_core.config import default_analysis_settings, func_class_lookup
from pavelife_core.outputs import build_excel_bytes
from pavelife_core.pro_bll import load_bll_artifacts
from pavelife_core.pro_runner import (
    PRO_DEFAULT_SETTINGS,
    PRO_MATERIAL_INPUT_DEFAULTS,
    run_pavelife_pro_single_section,
)


st.set_page_config(
    page_title="PaveLIFE-Pro",
    page_icon="🛣️",
    layout="wide",
)

if go is None:
    st.error("Plotly is required for this version of PaveLIFE-Pro Web. Please install it with: pip install plotly")
    st.stop()


plotly_config = {
    "displaylogo": False,
    "toImageButtonOptions": {
        "format": "png",
        "filename": "pavelife_plot",
        "height": 900,
        "width": 1400,
        "scale": 3,
    },
    "modeBarButtonsToRemove": ["lasso2d", "select2d"],
}

pavelife_palette = [
    "#2A9D8F",
    "#E76F51",
    "#457B9D",
    "#F4A261",
    "#6D597A",
    "#8AB17D",
    "#B56576",
    "#577590",
    "#D4A373",
    "#264653",
]

lca_palette = ["#DDEDE9", "#B6DED5", "#87C9BB", "#55B3A4", "#2A9D8F", "#1E7F73"]
lcca_palette = ["#FCE4D6", "#F8C9A8", "#F3A76F", "#E88445", "#D96C2C", "#B9541F"]


def apply_custom_css():
    st.markdown(
        """
        <style>
        .block-container {
            padding-top: 1.6rem;
            padding-bottom: 2.5rem;
            max-width: 1480px;
        }
        [data-testid="stSidebar"] {
            background: linear-gradient(180deg, #F7FAFC 0%, #EEF4F8 100%);
            border-right: 1px solid #D9E2EC;
        }
        [data-testid="stSidebar"] h1 {
            color: #17324D;
            letter-spacing: -0.02em;
        }
        [data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3 {
            color: #23395D;
        }
        div[data-testid="stMetric"] {
            background: #FFFFFF;
            border: 1px solid #E2E8F0;
            border-radius: 18px;
            padding: 1rem 1.1rem;
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.055);
        }
        div[data-testid="stMetric"] label {
            color: #5B677A;
            font-weight: 600;
        }
        .pavelife-hero {
            padding: 1.25rem 1.5rem;
            margin-bottom: 1.0rem;
            border-radius: 24px;
            border: 1px solid #D7E4EE;
            background: linear-gradient(135deg, #F8FBFD 0%, #EAF4F4 48%, #F8F1E9 100%);
            box-shadow: 0 12px 32px rgba(15, 23, 42, 0.06);
        }
        .pavelife-hero h1 {
            margin-bottom: 0.2rem;
            color: #172A3A;
            font-size: 2.15rem;
            letter-spacing: -0.035em;
        }
        .pavelife-hero p {
            margin-top: 0.35rem;
            color: #425466;
            font-size: 1.02rem;
            line-height: 1.55;
        }
        .pavelife-pill {
            display: inline-block;
            padding: 0.25rem 0.65rem;
            margin-right: 0.35rem;
            margin-top: 0.45rem;
            border-radius: 999px;
            background: rgba(42, 157, 143, 0.13);
            color: #1F6F67;
            font-size: 0.82rem;
            font-weight: 650;
        }
        .pavelife-note {
            padding: 0.8rem 1rem;
            border-radius: 16px;
            background: #F8FAFC;
            border: 1px solid #E2E8F0;
            color: #425466;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


apply_custom_css()


@st.cache_resource
def get_bll_artifact(pavement_family, model_dir):
    """Load the probabilistic BLL artifact for the selected pavement family."""
    return load_bll_artifacts(
        pavement_family=pavement_family,
        model_dir=model_dir,
    )


def get_bll_artifacts_for_families(pavement_families, model_dir):
    artifacts = {}
    for pavement_family in sorted(set(pavement_families)):
        artifacts[pavement_family] = get_bll_artifact(pavement_family, model_dir)
    return artifacts


def get_float_from_df(df, column_name, default_value=0.0):
    if isinstance(df, pd.DataFrame) and column_name in df.columns and len(df) > 0:
        value = pd.to_numeric(df[column_name].iloc[0], errors="coerce")
        if pd.notna(value):
            return float(value)
    return float(default_value)


def get_int_from_df(df, column_name, default_value=0):
    if isinstance(df, pd.DataFrame) and column_name in df.columns and len(df) > 0:
        value = pd.to_numeric(df[column_name].iloc[0], errors="coerce")
        if pd.notna(value):
            return int(value)
    return int(default_value)


func_class_label_to_code = {
    info["FUNC_CLASS_EXP"]: code for code, info in func_class_lookup.items()
}


def format_func_class_option(label):
    return label


def get_plot_layout(title=None, height=420):
    layout = dict(
        height=height,
        margin=dict(l=20, r=24, t=58 if title else 32, b=36),
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Arial", size=13, color="#334155"),
        hoverlabel=dict(bgcolor="white", font_size=12, font_family="Arial"),
    )
    if title:
        layout["title"] = dict(text=title, x=0.01, xanchor="left", font=dict(size=18, color="#172A3A"))
    return layout


def render_contribution_chart(contribution_df, label):
    if not isinstance(contribution_df, pd.DataFrame):
        return

    required_cols = ["Phase label", "Contribution rate (%)"]
    if not all(col in contribution_df.columns for col in required_cols):
        st.caption(f"{label} contribution chart skipped because expected columns were not found.")
        return

    chart_df = contribution_df[required_cols].copy()
    chart_df["Contribution rate (%)"] = pd.to_numeric(chart_df["Contribution rate (%)"], errors="coerce")
    chart_df = chart_df.dropna(subset=["Contribution rate (%)"])
    chart_df = chart_df.sort_values("Contribution rate (%)", ascending=True)

    palette = lca_palette if label.upper() == "LCA" else lcca_palette
    dominant_phase = ""
    if len(chart_df) > 0:
        dominant_phase = str(chart_df.loc[chart_df["Contribution rate (%)"].idxmax(), "Phase label"])

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=chart_df["Contribution rate (%)"],
            y=chart_df["Phase label"],
            orientation="h",
            marker=dict(
                color=chart_df["Contribution rate (%)"],
                colorscale=palette,
                line=dict(color="rgba(255,255,255,0.9)", width=1.2),
            ),
            text=chart_df["Contribution rate (%)"].map(lambda x: f"{x:.1f}%"),
            textposition="outside",
            cliponaxis=False,
            hovertemplate="<b>%{y}</b><br>Contribution: %{x:.2f}%<extra></extra>",
            name=label,
        )
    )
    fig.update_layout(
        **get_plot_layout(title=f"{label} contribution rate", height=390),
        showlegend=False,
        bargap=0.36,
        annotations=[
            dict(
                text=f"Dominant phase: <b>{dominant_phase}</b>" if dominant_phase else "",
                xref="paper",
                yref="paper",
                x=0.0,
                y=1.08,
                showarrow=False,
                align="left",
                font=dict(size=12, color="#64748B"),
            )
        ],
    )
    fig.update_xaxes(
        title="Contribution rate (%)",
        showgrid=True,
        gridcolor="#E5E7EB",
        zeroline=False,
        range=[0, max(100, float(chart_df["Contribution rate (%)"].max()) * 1.18 if len(chart_df) else 100)],
    )
    fig.update_yaxes(title="", showgrid=False, zeroline=False)
    st.plotly_chart(fig, use_container_width=True, config=plotly_config)


def get_iri_column(df_yearly):
    # PaveLIFE-Pro displays the posterior median trajectory by default.
    # The Monte Carlo LCA/LCCA distribution is generated from posterior samples.
    if "IRI_before_p50" in df_yearly.columns:
        return "IRI_before_p50", "Median IRI before maintenance"
    if "IRI_pred_before_maintenance" in df_yearly.columns:
        return "IRI_pred_before_maintenance", "Mean IRI before maintenance"
    if "IRI_pred" in df_yearly.columns:
        return "IRI_pred", "IRI after maintenance"
    return None, None


def render_iri_chart(df_yearly):
    """Render probabilistic IRI progression with uncertainty band and reliability."""
    if not isinstance(df_yearly, pd.DataFrame):
        return

    iri_col, iri_label = get_iri_column(df_yearly)
    if iri_col is None:
        st.caption("IRI chart skipped because no IRI prediction column was found.")
        return

    if "Pavement_Age" not in df_yearly.columns:
        st.caption("IRI chart skipped because Pavement_Age was not found.")
        return

    base_cols = ["Pavement_Age", iri_col]
    for extra_col in ["IRI_before_p05", "IRI_before_p95", "IRI_threshold", "Reliability_before_maintenance", "Required_reliability", "maintenance_flag"]:
        if extra_col in df_yearly.columns and extra_col not in base_cols:
            base_cols.append(extra_col)
    chart_df = df_yearly[base_cols].copy()
    for col in chart_df.columns:
        if col != "maintenance_flag":
            chart_df[col] = pd.to_numeric(chart_df[col], errors="coerce")
    chart_df = chart_df.dropna(subset=["Pavement_Age", iri_col])

    fig = go.Figure()

    if "IRI_before_p05" in chart_df.columns and "IRI_before_p95" in chart_df.columns:
        fig.add_trace(
            go.Scatter(
                x=chart_df["Pavement_Age"],
                y=chart_df["IRI_before_p95"],
                mode="lines",
                line=dict(width=0, color="rgba(42,157,143,0)"),
                showlegend=False,
                hoverinfo="skip",
            )
        )
        fig.add_trace(
            go.Scatter(
                x=chart_df["Pavement_Age"],
                y=chart_df["IRI_before_p05"],
                mode="lines",
                line=dict(width=0, color="rgba(42,157,143,0)"),
                fill="tonexty",
                fillcolor="rgba(42,157,143,0.18)",
                name="IRI P05-P95 interval",
                hovertemplate="Age: %{x:.0f} years<br>P05: %{y:.3f} m/km<extra></extra>",
            )
        )

    fig.add_trace(
        go.Scatter(
            x=chart_df["Pavement_Age"],
            y=chart_df[iri_col],
            mode="lines+markers",
            name=iri_label,
            line=dict(width=3.5, color="#2A9D8F", shape="spline", smoothing=0.55),
            marker=dict(size=5.5, color="#2A9D8F", line=dict(color="white", width=0.8)),
            hovertemplate="Age: %{x:.0f} years<br>IRI: %{y:.3f} m/km<extra></extra>",
        )
    )

    if "IRI_threshold" in chart_df.columns:
        threshold_value = pd.to_numeric(chart_df["IRI_threshold"].iloc[0], errors="coerce")
        if pd.notna(threshold_value):
            fig.add_hline(
                y=float(threshold_value),
                line=dict(color="#D94841", width=2.2, dash="dash"),
                annotation_text=f"IRI threshold = {float(threshold_value):.3f} m/km",
                annotation_position="top left",
                annotation_font=dict(color="#9B2C2C", size=12),
            )

    if "maintenance_flag" in chart_df.columns:
        maintenance_df = chart_df[pd.to_numeric(chart_df["maintenance_flag"], errors="coerce") == 1].copy()
        if len(maintenance_df) > 0:
            fig.add_trace(
                go.Scatter(
                    x=maintenance_df["Pavement_Age"],
                    y=maintenance_df[iri_col],
                    mode="markers",
                    name="M&R event",
                    marker=dict(symbol="diamond", size=13, color="#E76F51", line=dict(color="white", width=1.4)),
                    hovertemplate="M&R event<br>Age: %{x:.0f} years<br>IRI before treatment: %{y:.3f} m/km<extra></extra>",
                )
            )

    fig.update_layout(
        **get_plot_layout(title="Probabilistic IRI progression and reliability-based M&R", height=480),
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
            bgcolor="rgba(255,255,255,0.75)",
        ),
    )
    fig.update_xaxes(title="Pavement age (years)", showgrid=True, gridcolor="#E5E7EB", zeroline=False)
    fig.update_yaxes(title="IRI (m/km)", showgrid=True, gridcolor="#E5E7EB", zeroline=False, rangemode="tozero")
    st.plotly_chart(fig, use_container_width=True, config=plotly_config)

    if "Reliability_before_maintenance" in chart_df.columns:
        rel_df = chart_df.dropna(subset=["Reliability_before_maintenance"]).copy()
        if len(rel_df) > 0:
            rel_fig = go.Figure()
            rel_fig.add_trace(
                go.Scatter(
                    x=rel_df["Pavement_Age"],
                    y=rel_df["Reliability_before_maintenance"] * 100.0,
                    mode="lines+markers",
                    name="Reliability before M&R",
                    line=dict(width=3.0, color="#457B9D", shape="spline", smoothing=0.45),
                    marker=dict(size=5, color="#457B9D", line=dict(color="white", width=0.8)),
                    hovertemplate="Age: %{x:.0f} years<br>Reliability: %{y:.1f}%<extra></extra>",
                )
            )
            if "Required_reliability" in rel_df.columns:
                req = pd.to_numeric(rel_df["Required_reliability"].iloc[0], errors="coerce")
                if pd.notna(req):
                    rel_fig.add_hline(
                        y=float(req) * 100.0,
                        line=dict(color="#D94841", width=2.0, dash="dash"),
                        annotation_text=f"Required reliability = {float(req) * 100:.0f}%",
                        annotation_position="bottom left",
                    )
            rel_fig.update_layout(
                **get_plot_layout(title="Service reliability trajectory", height=320),
                showlegend=False,
                hovermode="x unified",
            )
            rel_fig.update_xaxes(title="Pavement age (years)", showgrid=True, gridcolor="#E5E7EB", zeroline=False)
            rel_fig.update_yaxes(title="P(IRI < threshold), %", range=[0, 105], showgrid=True, gridcolor="#E5E7EB", zeroline=False)
            st.plotly_chart(rel_fig, use_container_width=True, config=plotly_config)

    st.caption(f"Displayed IRI series: `{iri_col}`. Probability band uses posterior BLL samples where available.")

def render_comparison_iri_chart(comparison_items):
    fig = go.Figure()
    any_trace = False

    for idx, item in enumerate(comparison_items):
        df_yearly = item["results"].get("yearly_iri")
        if not isinstance(df_yearly, pd.DataFrame) or "Pavement_Age" not in df_yearly.columns:
            continue
        iri_col, _ = get_iri_column(df_yearly)
        if iri_col is None:
            continue
        color = pavelife_palette[idx % len(pavelife_palette)]
        chart_df = df_yearly[["Pavement_Age", iri_col]].copy()
        chart_df["Pavement_Age"] = pd.to_numeric(chart_df["Pavement_Age"], errors="coerce")
        chart_df[iri_col] = pd.to_numeric(chart_df[iri_col], errors="coerce")
        chart_df = chart_df.dropna(subset=["Pavement_Age", iri_col])
        fig.add_trace(
            go.Scatter(
                x=chart_df["Pavement_Age"],
                y=chart_df[iri_col],
                mode="lines",
                name=item["design_label"],
                line=dict(width=3, color=color, shape="spline", smoothing=0.45),
                hovertemplate=(
                    f"<b>{item['design_label']}</b><br>"
                    "Age: %{x:.0f} years<br>IRI: %{y:.3f} m/km<extra></extra>"
                ),
            )
        )
        any_trace = True

    if not any_trace:
        st.caption("Comparison IRI chart skipped because no valid IRI prediction column was found.")
        return

    first_df = comparison_items[0]["results"].get("yearly_iri")
    if isinstance(first_df, pd.DataFrame) and "IRI_threshold" in first_df.columns:
        threshold_value = pd.to_numeric(first_df["IRI_threshold"].iloc[0], errors="coerce")
        if pd.notna(threshold_value):
            fig.add_hline(
                y=float(threshold_value),
                line=dict(color="#D94841", width=2.0, dash="dash"),
                annotation_text=f"IRI threshold = {float(threshold_value):.3f} m/km",
                annotation_position="top left",
                annotation_font=dict(color="#9B2C2C", size=12),
            )

    fig.update_layout(
        **get_plot_layout(title="IRI progression comparison", height=500),
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
            bgcolor="rgba(255,255,255,0.76)",
        ),
    )
    fig.update_xaxes(title="Pavement age (years)", showgrid=True, gridcolor="#E5E7EB", zeroline=False)
    fig.update_yaxes(title="IRI (m/km)", showgrid=True, gridcolor="#E5E7EB", zeroline=False, rangemode="tozero")
    st.plotly_chart(fig, use_container_width=True, config=plotly_config)


def parse_maintenance_years(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return [int(x) for x in value if pd.notna(x)]
    text = str(value).strip()
    if text == "" or text.lower() == "nan":
        return []
    years = []
    for part in text.replace(";", ",").split(","):
        part_clean = part.strip()
        if part_clean:
            try:
                years.append(int(float(part_clean)))
            except ValueError:
                pass
    return years


def get_maintenance_years_from_results(results):
    maintenance_summary = results.get("maintenance_summary")
    if isinstance(maintenance_summary, pd.DataFrame) and "maintenance_years" in maintenance_summary.columns and len(maintenance_summary) > 0:
        return parse_maintenance_years(maintenance_summary["maintenance_years"].iloc[0])
    if isinstance(maintenance_summary, pd.DataFrame) and "Maintenance Years" in maintenance_summary.columns and len(maintenance_summary) > 0:
        return parse_maintenance_years(maintenance_summary["Maintenance Years"].iloc[0])
    return []


def render_maintenance_timeline(comparison_items):
    rows = []
    for item in comparison_items:
        years = get_maintenance_years_from_results(item["results"])
        for year in years:
            rows.append({"Design": item["design_label"], "Maintenance year": year})

    if not rows:
        st.info("No maintenance events were triggered for the compared designs within the analysis period.")
        return

    timeline_df = pd.DataFrame(rows)
    fig = go.Figure()
    for idx, design in enumerate(timeline_df["Design"].unique()):
        sub_df = timeline_df[timeline_df["Design"] == design]
        color = pavelife_palette[idx % len(pavelife_palette)]
        fig.add_trace(
            go.Scatter(
                x=sub_df["Maintenance year"],
                y=sub_df["Design"],
                mode="markers",
                marker=dict(symbol="diamond", size=13, color=color, line=dict(color="white", width=1.2)),
                name=design,
                hovertemplate="<b>%{y}</b><br>M&R year: %{x}<extra></extra>",
            )
        )

    fig.update_layout(
        **get_plot_layout(title="Maintenance event timeline", height=max(300, 72 + 36 * len(timeline_df["Design"].unique()))),
        showlegend=False,
    )
    fig.update_xaxes(title="Pavement age (years)", showgrid=True, gridcolor="#E5E7EB", zeroline=False)
    fig.update_yaxes(title="", showgrid=False, zeroline=False)
    st.plotly_chart(fig, use_container_width=True, config=plotly_config)


def render_metric_comparison_bar(summary_df, value_col, title, unit_label, color_scale):
    if not isinstance(summary_df, pd.DataFrame) or value_col not in summary_df.columns:
        return
    chart_df = summary_df[["Design", value_col]].copy()
    chart_df[value_col] = pd.to_numeric(chart_df[value_col], errors="coerce")
    chart_df = chart_df.dropna(subset=[value_col]).sort_values(value_col, ascending=True)
    if len(chart_df) == 0:
        return

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=chart_df[value_col],
            y=chart_df["Design"],
            orientation="h",
            marker=dict(
                color=chart_df[value_col],
                colorscale=color_scale,
                line=dict(color="rgba(255,255,255,0.9)", width=1.2),
            ),
            text=chart_df[value_col].map(lambda x: f"{x:,.0f}"),
            textposition="outside",
            cliponaxis=False,
            hovertemplate=f"<b>%{{y}}</b><br>{title}: %{{x:,.2f}} {unit_label}<extra></extra>",
        )
    )
    fig.update_layout(
        **get_plot_layout(title=title, height=max(360, 120 + 34 * len(chart_df))),
        showlegend=False,
        bargap=0.34,
    )
    fig.update_xaxes(title=unit_label, showgrid=True, gridcolor="#E5E7EB", zeroline=False)
    fig.update_yaxes(title="", showgrid=False, zeroline=False)
    st.plotly_chart(fig, use_container_width=True, config=plotly_config)




def render_distribution_histogram(distribution_df, value_col, title, unit_label, color="#2A9D8F"):
    """Render a probability-distribution chart for LCA/LCCA outputs."""
    if not isinstance(distribution_df, pd.DataFrame) or value_col not in distribution_df.columns:
        st.caption(f"{title} skipped because `{value_col}` was not found.")
        return
    values = pd.to_numeric(distribution_df[value_col], errors="coerce").dropna()
    if len(values) == 0:
        st.caption(f"{title} skipped because no valid values were available.")
        return

    mean_v = float(values.mean())
    p05 = float(values.quantile(0.05))
    p50 = float(values.quantile(0.50))
    p95 = float(values.quantile(0.95))

    fig = go.Figure()
    fig.add_trace(
        go.Histogram(
            x=values,
            nbinsx=min(40, max(12, int(len(values) ** 0.5))),
            histnorm="probability density",
            marker=dict(color=color, opacity=0.62, line=dict(color="white", width=0.7)),
            name="Monte Carlo density",
            hovertemplate=f"{value_col}: %{{x:,.2f}} {unit_label}<br>Density: %{{y:.4f}}<extra></extra>",
        )
    )
    fig.add_vline(x=mean_v, line=dict(color="#172A3A", width=2.2), annotation_text=f"Mean = {mean_v:,.0f}", annotation_position="top right")
    fig.add_vline(x=p05, line=dict(color="#D94841", width=1.8, dash="dash"), annotation_text="P05", annotation_position="bottom left")
    fig.add_vline(x=p50, line=dict(color="#457B9D", width=1.8, dash="dot"), annotation_text="P50", annotation_position="top left")
    fig.add_vline(x=p95, line=dict(color="#D94841", width=1.8, dash="dash"), annotation_text="P95", annotation_position="bottom right")
    fig.update_layout(
        **get_plot_layout(title=title, height=380),
        showlegend=False,
        bargap=0.04,
    )
    fig.update_xaxes(title=unit_label, showgrid=True, gridcolor="#E5E7EB", zeroline=False)
    fig.update_yaxes(title="Probability density", showgrid=True, gridcolor="#E5E7EB", zeroline=False)
    st.plotly_chart(fig, use_container_width=True, config=plotly_config)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Mean", f"{mean_v:,.0f}")
    c2.metric("P05", f"{p05:,.0f}")
    c3.metric("P50", f"{p50:,.0f}")
    c4.metric("P95", f"{p95:,.0f}")

def build_combined_contribution_df(comparison_items, contribution_key):
    rows = []
    for item in comparison_items:
        contribution_df = item["results"].get(contribution_key)
        if not isinstance(contribution_df, pd.DataFrame):
            continue
        if not all(col in contribution_df.columns for col in ["Phase label", "Contribution rate (%)"]):
            continue
        for _, row in contribution_df.iterrows():
            rows.append(
                {
                    "Design": item["design_label"],
                    "Phase": row["Phase label"],
                    "Contribution rate (%)": pd.to_numeric(row["Contribution rate (%)"], errors="coerce"),
                }
            )
    return pd.DataFrame(rows)


def render_comparison_contribution_stacked(comparison_items, contribution_key, title):
    contribution_df = build_combined_contribution_df(comparison_items, contribution_key)
    if len(contribution_df) == 0:
        st.caption(f"{title} skipped because no valid contribution table was found.")
        return
    phase_order = list(dict.fromkeys(contribution_df["Phase"].tolist()))
    design_order = list(dict.fromkeys([item["design_label"] for item in comparison_items]))

    fig = go.Figure()
    for idx, phase in enumerate(phase_order):
        sub_df = contribution_df[contribution_df["Phase"] == phase]
        value_map = dict(zip(sub_df["Design"], sub_df["Contribution rate (%)"]))
        x_values = [value_map.get(design, 0.0) for design in design_order]
        fig.add_trace(
            go.Bar(
                x=x_values,
                y=design_order,
                orientation="h",
                name=phase,
                marker=dict(color=pavelife_palette[idx % len(pavelife_palette)], line=dict(color="white", width=0.8)),
                hovertemplate="<b>%{y}</b><br>Phase: " + phase + "<br>Contribution: %{x:.2f}%<extra></extra>",
            )
        )

    fig.update_layout(
        **get_plot_layout(title=title, height=max(380, 140 + 35 * len(design_order))),
        barmode="stack",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
            bgcolor="rgba(255,255,255,0.78)",
        ),
    )
    fig.update_xaxes(title="Contribution rate (%)", showgrid=True, gridcolor="#E5E7EB", zeroline=False, range=[0, 100])
    fig.update_yaxes(title="", showgrid=False, zeroline=False)
    st.plotly_chart(fig, use_container_width=True, config=plotly_config)


def build_common_inputs():
    shrp_id = st.text_input(
        "Section / scenario ID",
        value="demo_001",
        help="Shared section or scenario identifier.",
    )

    iri0 = st.number_input(
        "Initial IRI, m/km",
        min_value=0.01,
        value=0.95,
        step=0.05,
        help="Initial International Roughness Index shared by all compared designs.",
    )

    func_class_label = st.selectbox(
        "Functional class",
        options=list(func_class_label_to_code.keys()),
        index=0,
        format_func=format_func_class_option,
        help="The selected functional class determines the IRI trigger threshold and speed assumptions.",
    )
    func_class = func_class_label_to_code[func_class_label]

    func_info = func_class_lookup[int(func_class)]
    st.info(
        f"**{func_class_label}**\n\n"
        f"IRI threshold: {func_info['IRI_threshold']} m/km  \n"
        f"Car speed limit: {func_info['car_speed_limit_kph']} km/h  \n"
        f"Truck speed limit: {func_info['truck_speed_limit_kph']} km/h"
    )

    st.header("2. Shared climate and traffic")
    precipitation = st.number_input("Precipitation, mm", min_value=0.0, value=800.0, step=10.0)
    temperature = st.number_input("Temperature, °C", value=15.0, step=1.0)
    freeze_index = st.number_input("Freeze index, °C*days", min_value=0.0, value=100.0, step=10.0)
    aadt = st.number_input("AADT, vehicles/day", min_value=0.0, value=8000.0, step=100.0)
    aadtt = st.number_input("AADTT, trucks/day", min_value=0.0, value=800.0, step=50.0)
    kesal = st.number_input("KESAL", min_value=0.0, value=500.0, step=10.0)

    st.header("3. Shared asphalt mixture/material variables")
    st.caption("These material variables are used by the PaveLIFE-Pro probabilistic BLL IRI model. They are shared across compared designs unless changed by a future design-level material module.")
    no4_passing = st.number_input("NO. 4 passing, %", min_value=0.0, max_value=100.0, value=float(PRO_MATERIAL_INPUT_DEFAULTS["no4_passing"]), step=1.0)
    no200_passing = st.number_input("NO. 200 passing / second gradation passing, %", min_value=0.0, max_value=100.0, value=float(PRO_MATERIAL_INPUT_DEFAULTS["no200_passing"]), step=1.0)
    air_voids = st.number_input("Air voids, %", min_value=0.0, max_value=30.0, value=float(PRO_MATERIAL_INPUT_DEFAULTS["air_voids"]), step=0.1)
    asphalt_content = st.number_input("Asphalt content, %", min_value=0.0, max_value=20.0, value=float(PRO_MATERIAL_INPUT_DEFAULTS["asphalt_content"]), step=0.1)
    vma = st.number_input("VMA, %", min_value=0.0, max_value=40.0, value=float(PRO_MATERIAL_INPUT_DEFAULTS["vma"]), step=0.1)
    vfa = st.number_input("VFA, %", min_value=0.0, max_value=100.0, value=float(PRO_MATERIAL_INPUT_DEFAULTS["vfa"]), step=1.0)

    common_input = {
        "shrp_id": shrp_id,
        "iri0": iri0,
        "precipitation": precipitation,
        "temperature": temperature,
        "freeze_index": freeze_index,
        "aadt": aadt,
        "aadtt": aadtt,
        "kesal": kesal,
        "func_class": func_class,
        "no4_passing": no4_passing,
        "no200_passing": no200_passing,
        "air_voids": air_voids,
        "asphalt_content": asphalt_content,
        "vma": vma,
        "vfa": vfa,
    }
    return common_input


def build_design_input(prefix, default_label, default_family="asphalt", default_type=None, expanded=False):
    with st.expander(default_label, expanded=expanded):
        design_label = st.text_input("Design label", value=default_label, key=f"{prefix}_design_label")
        pavement_family = st.selectbox(
            "Pavement family",
            options=["asphalt", "concrete"],
            index=0 if default_family == "asphalt" else 1,
            key=f"{prefix}_pavement_family",
        )

        if pavement_family == "asphalt":
            pavement_type_options = ["ACUB", "ACATB", "ACCTB", "FDA", "IP"]
        else:
            pavement_type_options = ["JPCP", "JRCP", "CRCP"]
            st.warning("Concrete is kept as a PaveLIFE-Pro placeholder. The probabilistic BLL IRI model is currently available only for asphalt designs.")

        if default_type in pavement_type_options:
            default_type_index = pavement_type_options.index(default_type)
        else:
            default_type_index = 0

        pavement_type = st.selectbox(
            "Pavement type",
            options=pavement_type_options,
            index=default_type_index,
            key=f"{prefix}_pavement_type",
        )

        st.caption("Input layer thicknesses directly in meters. PaveLIFE-Pro automatically converts them to inches only for the probabilistic BLL IRI model; LCA/LCCA use meters.")
        surface_thickness = st.number_input(
            "Surface thickness, m",
            min_value=0.0,
            value=0.15,
            step=0.01,
            format="%.3f",
            key=f"{prefix}_surface_thickness",
        )
        base_thickness = st.number_input(
            "Base thickness, m",
            min_value=0.0,
            value=0.25,
            step=0.01,
            format="%.3f",
            key=f"{prefix}_base_thickness",
        )
        subbase_thickness = st.number_input(
            "Subbase thickness, m",
            min_value=0.0,
            value=0.20,
            step=0.01,
            format="%.3f",
            key=f"{prefix}_subbase_thickness",
        )

    design_input = {
        "design_label": design_label,
        "pavement_family": pavement_family,
        "pavement_type": pavement_type,
        "surface_thickness": surface_thickness,
        "base_thickness": base_thickness,
        "subbase_thickness": subbase_thickness,
    }
    return design_input


def apply_expert_settings(analysis_settings, mode):
    if mode != "Expert mode":
        return analysis_settings

    with st.expander("Expert: geometry and traffic", expanded=False):
        analysis_settings["analysis_base_year"] = int(
            st.number_input(
                "Analysis base year",
                min_value=1900,
                max_value=2200,
                value=int(default_analysis_settings["analysis_base_year"]),
                step=1,
            )
        )
        analysis_settings["growth_rate"] = float(
            st.number_input(
                "Annual traffic growth rate",
                min_value=0.0,
                max_value=0.20,
                value=float(default_analysis_settings["growth_rate"]),
                step=0.005,
                format="%.3f",
            )
        )
        analysis_settings["lane_length"] = float(
            st.number_input(
                "Lane length, m",
                min_value=1.0,
                value=float(default_analysis_settings["lane_length"]),
                step=100.0,
            )
        )
        analysis_settings["lane_width"] = float(
            st.number_input(
                "Lane width, m",
                min_value=1.0,
                value=float(default_analysis_settings["lane_width"]),
                step=0.1,
            )
        )

    with st.expander("Expert: work-zone and maintenance", expanded=False):
        analysis_settings["work_zone_speed_kph"] = float(
            st.number_input("Work-zone speed, km/h", min_value=1.0, value=float(default_analysis_settings["work_zone_speed_kph"]), step=5.0)
        )
        analysis_settings["work_hours_per_day"] = float(
            st.number_input("Work hours per day", min_value=1.0, value=float(default_analysis_settings["work_hours_per_day"]), step=1.0)
        )
        analysis_settings["overlay_only_duration_days"] = float(
            st.number_input("Overlay-only duration, days", min_value=0.0, value=float(default_analysis_settings["overlay_only_duration_days"]), step=1.0)
        )
        analysis_settings["mill_and_overlay_duration_days"] = float(
            st.number_input("Mill-and-overlay duration, days", min_value=0.0, value=float(default_analysis_settings["mill_and_overlay_duration_days"]), step=1.0)
        )
        analysis_settings["cpr_diamond_grinding_duration_days"] = float(
            st.number_input("CPR / diamond grinding duration, days", min_value=0.0, value=float(default_analysis_settings["cpr_diamond_grinding_duration_days"]), step=1.0)
        )
        analysis_settings["share_of_directional_traffic_during_work_hours"] = float(
            st.number_input(
                "Share of directional traffic during work hours",
                min_value=0.0,
                max_value=1.0,
                value=float(default_analysis_settings["share_of_directional_traffic_during_work_hours"]),
                step=0.01,
                format="%.3f",
            )
        )
        analysis_settings["peak_hour_multiplier"] = float(
            st.number_input("Peak-hour multiplier", min_value=0.0, value=float(default_analysis_settings["peak_hour_multiplier"]), step=0.05, format="%.2f")
        )
        analysis_settings["work_zone_capacity_per_open_lane_vehph"] = float(
            st.number_input(
                "Work-zone capacity per open lane, veh/h/lane",
                min_value=1.0,
                value=float(default_analysis_settings["work_zone_capacity_per_open_lane_vehph"]),
                step=50.0,
            )
        )
        analysis_settings["mr_open_lanes"] = int(
            st.number_input("Open lanes during M&R", min_value=1, max_value=20, value=int(default_analysis_settings["mr_open_lanes"]), step=1)
        )

    with st.expander("Expert: LCA emission factors", expanded=False):
        analysis_settings["asphalt_prod_factor"] = float(
            st.number_input("Asphalt production EF, kg CO₂e/ton", value=float(default_analysis_settings["asphalt_prod_factor"]), step=1.0)
        )
        analysis_settings["concrete_prod_factor"] = float(
            st.number_input("Concrete production EF, kg CO₂e/ton", value=float(default_analysis_settings["concrete_prod_factor"]), step=1.0)
        )
        analysis_settings["aggregate_prod_factor"] = float(
            st.number_input("Aggregate production EF, kg CO₂e/ton", value=float(default_analysis_settings["aggregate_prod_factor"]), step=0.5)
        )
        analysis_settings["ctb_prod_factor"] = float(
            st.number_input("CTB production EF, kg CO₂e/ton", value=float(default_analysis_settings["ctb_prod_factor"]), step=1.0)
        )
        analysis_settings["atb_prod_factor"] = float(
            st.number_input("ATB production EF, kg CO₂e/ton", value=float(default_analysis_settings["atb_prod_factor"]), step=1.0)
        )
        analysis_settings["rebar_prod_factor"] = float(
            st.number_input("Rebar production EF, kg CO₂e/ton", value=float(default_analysis_settings["rebar_prod_factor"]), step=50.0)
        )

    with st.expander("Expert: LCCA assumptions", expanded=False):
        analysis_settings["gasoline_price_per_gallon"] = float(
            st.number_input("Gasoline price, USD/gal", value=float(default_analysis_settings["gasoline_price_per_gallon"]), step=0.1)
        )
        analysis_settings["diesel_price_per_gallon"] = float(
            st.number_input("Diesel price, USD/gal", value=float(default_analysis_settings["diesel_price_per_gallon"]), step=0.1)
        )
        analysis_settings["asphalt_material_cost_per_ton"] = float(
            st.number_input("Asphalt material cost, USD/ton", value=float(default_analysis_settings["asphalt_material_cost_per_ton"]), step=1.0)
        )
        analysis_settings["concrete_material_cost_per_ton"] = float(
            st.number_input("Concrete material cost, USD/ton", value=float(default_analysis_settings["concrete_material_cost_per_ton"]), step=1.0)
        )
        analysis_settings["aggregate_material_cost_per_ton"] = float(
            st.number_input("Aggregate material cost, USD/ton", value=float(default_analysis_settings["aggregate_material_cost_per_ton"]), step=1.0)
        )
        analysis_settings["reinforcement_ratio"] = float(
            st.number_input(
                "Reinforcement ratio for JRCP/CRCP",
                min_value=0.0,
                max_value=0.20,
                value=float(default_analysis_settings["reinforcement_ratio"]),
                step=0.001,
                format="%.4f",
            )
        )

    with st.expander("Expert: probabilistic policy optimization", expanded=False):
        analysis_settings["use_ppo_optimization"] = bool(
            st.checkbox(
                "Use experimental PPO project-level M&R policy",
                value=bool(PRO_DEFAULT_SETTINGS["use_ppo_optimization"]),
                help="If enabled, PaveLIFE-Pro trains a lightweight PPO policy during the run to propose M&R years. Requires gymnasium and stable-baselines3. Reliability-triggered policy is recommended for routine use.",
            )
        )
        analysis_settings["ppo_total_timesteps"] = int(
            st.number_input(
                "PPO total timesteps",
                min_value=1000,
                max_value=1000000,
                value=int(PRO_DEFAULT_SETTINGS["ppo_total_timesteps"]),
                step=1000,
            )
        )
        analysis_settings["ppo_seed"] = int(
            st.number_input(
                "PPO random seed",
                min_value=0,
                max_value=999999,
                value=int(PRO_DEFAULT_SETTINGS["ppo_seed"]),
                step=1,
            )
        )

    return analysis_settings


def build_sidebar_inputs():
    with st.sidebar:
        st.title("PaveLIFE-Pro")
        st.caption("Single-section and design-comparison pavement LCA-LCCA decision-support tool")

        analysis_mode = st.radio(
            "Analysis mode",
            options=["Single pavement design", "Design comparison"],
            index=0,
            help="Single design evaluates one pavement structure. Design comparison evaluates up to 10 alternatives under the same climate, traffic, and analysis assumptions.",
        )

        input_mode = st.radio(
            "Input mode",
            options=["Basic mode", "Expert mode"],
            index=0,
            help="Basic mode exposes core inputs. Expert mode exposes selected LCA/LCCA assumptions.",
        )

        st.divider()
        st.header("1. Shared section context")
        common_input = build_common_inputs()

        if analysis_mode == "Single pavement design":
            st.header("4. Pavement design")
            design_input = build_design_input(
                prefix="single",
                default_label="Single design",
                default_family="asphalt",
                default_type="ACUB",
                expanded=True,
            )
            design_inputs = [design_input]
        else:
            st.header("4. Design alternatives")
            st.caption("All designs share the same IRI0, functional class, climate, traffic, material variables, and analysis assumptions. Currently, probabilistic BLL prediction is implemented for asphalt designs only; concrete remains a visible placeholder for future model integration.")
            number_of_designs = st.number_input(
                "Number of designs to compare",
                min_value=2,
                max_value=10,
                value=3,
                step=1,
            )
            design_inputs = []
            default_types = ["ACUB", "ACATB", "ACCTB", "FDA", "IP", "ACUB", "ACATB", "ACCTB", "FDA", "IP"]
            for idx in range(int(number_of_designs)):
                default_type = default_types[idx % len(default_types)]
                default_family = "concrete" if default_type in ["JPCP", "JRCP", "CRCP"] else "asphalt"
                design_inputs.append(
                    build_design_input(
                        prefix=f"comparison_{idx + 1}",
                        default_label=f"Design {idx + 1}",
                        default_family=default_family,
                        default_type=default_type,
                        expanded=(idx < 2),
                    )
                )

        st.header("5. Analysis settings")
        model_dir_default = os.path.join(os.getcwd(), "model_artifacts")
        model_dir = st.text_input(
            "Model artifact folder",
            value=model_dir_default,
            help="Folder containing PaveLIFE-Pro BLL artifacts: model_artifacts/probabilistic/asphalt/iri_scaler_bll_v2.joblib, iri_model_package_bll_v2.pt, and the Pyro parameter-store file.",
        )

        analysis_years = st.number_input(
            "Analysis period, years",
            min_value=1,
            max_value=100,
            value=int(default_analysis_settings["analysis_years"]),
            step=1,
        )

        real_discount_rate = st.number_input(
            "Real discount rate",
            min_value=0.0,
            max_value=0.20,
            value=float(default_analysis_settings["real_discount_rate"]),
            step=0.005,
            format="%.3f",
        )

        st.subheader("Probabilistic settings")
        num_prediction_samples = st.number_input(
            "BLL posterior predictive samples",
            min_value=100,
            max_value=5000,
            value=int(PRO_DEFAULT_SETTINGS["num_prediction_samples"]),
            step=100,
            help="Number of posterior predictive Rate_Log samples drawn from the BLL model.",
        )
        num_life_cycle_samples = st.number_input(
            "LCA/LCCA Monte Carlo samples",
            min_value=20,
            max_value=1000,
            value=int(PRO_DEFAULT_SETTINGS["num_life_cycle_samples"]),
            step=20,
            help="Number of posterior deterioration samples used to estimate LCA/LCCA probability distributions.",
        )

        analysis_settings = default_analysis_settings.copy()
        analysis_settings.update(PRO_DEFAULT_SETTINGS)
        analysis_settings["analysis_years"] = int(analysis_years)
        analysis_settings["analysis_period_years"] = int(analysis_years)
        analysis_settings["real_discount_rate"] = float(real_discount_rate)
        analysis_settings["thickness_unit_to_m"] = 1.0
        analysis_settings["num_prediction_samples"] = int(num_prediction_samples)
        analysis_settings["num_life_cycle_samples"] = int(num_life_cycle_samples)
        analysis_settings = apply_expert_settings(analysis_settings, input_mode)

        run_button = st.button("Run PaveLIFE", type="primary", use_container_width=True)

    return analysis_mode, input_mode, common_input, design_inputs, analysis_settings, model_dir, run_button


def build_input_dict(common_input, design_input, design_index=1):
    shrp_id = common_input["shrp_id"]
    design_label = design_input.get("design_label", f"Design {design_index}")
    input_dict = {
        "shrp_id": f"{shrp_id}_{design_label}" if design_label else shrp_id,
        "pavement_family": design_input["pavement_family"],
        "pavement_type": design_input["pavement_type"],
        "iri0": common_input["iri0"],
        "precipitation": common_input["precipitation"],
        "temperature": common_input["temperature"],
        "freeze_index": common_input["freeze_index"],
        "aadt": common_input["aadt"],
        "aadtt": common_input["aadtt"],
        "kesal": common_input["kesal"],
        "surface_thickness": design_input["surface_thickness"],
        "base_thickness": design_input["base_thickness"],
        "subbase_thickness": design_input["subbase_thickness"],
        "func_class": common_input["func_class"],
        "no4_passing": common_input.get("no4_passing", PRO_MATERIAL_INPUT_DEFAULTS["no4_passing"]),
        "no200_passing": common_input.get("no200_passing", PRO_MATERIAL_INPUT_DEFAULTS["no200_passing"]),
        "air_voids": common_input.get("air_voids", PRO_MATERIAL_INPUT_DEFAULTS["air_voids"]),
        "asphalt_content": common_input.get("asphalt_content", PRO_MATERIAL_INPUT_DEFAULTS["asphalt_content"]),
        "vma": common_input.get("vma", PRO_MATERIAL_INPUT_DEFAULTS["vma"]),
        "vfa": common_input.get("vfa", PRO_MATERIAL_INPUT_DEFAULTS["vfa"]),
    }
    return input_dict


def run_single_design(input_dict, analysis_settings, model_dir):
    pavement_family = input_dict["pavement_family"]
    bll_artifact = get_bll_artifact(pavement_family, model_dir)
    results = run_pavelife_pro_single_section(
        input_dict=input_dict,
        analysis_settings=analysis_settings,
        model_dir=model_dir,
        bll_artifacts=bll_artifact,
        output_dir=os.path.join(os.getcwd(), "outputs"),
    )
    return results


def run_design_comparison(common_input, design_inputs, analysis_settings, model_dir):
    pavement_families = [design_input["pavement_family"] for design_input in design_inputs]
    bll_artifacts = get_bll_artifacts_for_families(pavement_families, model_dir)
    comparison_items = []
    progress_bar = st.progress(0.0)

    for idx, design_input in enumerate(design_inputs):
        input_dict = build_input_dict(common_input, design_input, design_index=idx + 1)
        results = run_pavelife_pro_single_section(
            input_dict=input_dict,
            analysis_settings=analysis_settings,
            model_dir=model_dir,
            bll_artifacts=bll_artifacts[input_dict["pavement_family"]],
            output_dir=os.path.join(os.getcwd(), "outputs"),
        )
        design_label = design_input.get("design_label", f"Design {idx + 1}")
        if not design_label:
            design_label = f"Design {idx + 1}"
        comparison_items.append(
            {
                "design_label": design_label,
                "input_dict": input_dict,
                "design_input": design_input,
                "results": results,
            }
        )
        progress_bar.progress((idx + 1) / len(design_inputs))

    progress_bar.empty()
    return comparison_items


def build_comparison_summary(comparison_items):
    rows = []
    for item in comparison_items:
        results = item["results"]
        input_dict = item["input_dict"]
        rate_prediction = results.get("rate_prediction")
        maintenance_summary = results.get("maintenance_summary")
        lca_summary = results.get("lca_summary")
        lcca_summary = results.get("lcca_summary")
        maintenance_years = get_maintenance_years_from_results(results)

        rows.append(
            {
                "Design": item["design_label"],
                "Pavement family": input_dict["pavement_family"],
                "Pavement type": input_dict["pavement_type"],
                "Surface thickness, m": input_dict["surface_thickness"],
                "Base thickness, m": input_dict["base_thickness"],
                "Subbase thickness, m": input_dict["subbase_thickness"],
                "Rate_Log mean": get_float_from_df(rate_prediction, "rate_log_pred", 0.0),
                "Rate_Log p05": get_float_from_df(rate_prediction, "rate_log_p05", 0.0),
                "Rate_Log p95": get_float_from_df(rate_prediction, "rate_log_p95", 0.0),
                "Rate mean": get_float_from_df(rate_prediction, "rate_pred", 0.0),
                "Maintenance count": get_int_from_df(maintenance_summary, "maintenance_count", len(maintenance_years)),
                "First maintenance year": maintenance_years[0] if maintenance_years else "",
                "Maintenance years": ", ".join(str(year) for year in maintenance_years),
                "Total GHG, kg CO2e": get_float_from_df(lca_summary, "Total Emission", 0.0),
                "Total cost PV, USD": get_float_from_df(lcca_summary, "Total Cost", 0.0),
            }
        )
    return pd.DataFrame(rows)


def build_comparison_excel_bytes(comparison_items, comparison_summary_df):
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        comparison_summary_df.to_excel(writer, sheet_name="comparison_summary", index=False)
        for idx, item in enumerate(comparison_items, start=1):
            label = str(item["design_label"])
            safe_label = "".join(ch if ch.isalnum() else "_" for ch in label)[:12]
            results = item["results"]
            sheet_prefix = f"D{idx}_{safe_label}"
            for key in ["input_parameters", "rate_prediction", "yearly_iri", "maintenance_summary", "lca_summary", "lca_phase_contribution", "lcca_summary", "lcca_phase_contribution"]:
                value = results.get(key)
                if isinstance(value, pd.DataFrame):
                    sheet_name = f"{sheet_prefix}_{key}"[:31]
                    value.to_excel(writer, sheet_name=sheet_name, index=False)
    output.seek(0)
    return output.getvalue()


def render_single_results(results, input_dict_current, input_mode):
    rate_prediction = results["rate_prediction"]
    maintenance_summary = results["maintenance_summary"]
    lca_summary = results["lca_summary"]
    lcca_summary = results["lcca_summary"]

    rate_pred = get_float_from_df(rate_prediction, "rate_pred", default_value=0.0)
    rate_log_pred = get_float_from_df(rate_prediction, "rate_log_pred", default_value=0.0)
    rate_log_p05 = get_float_from_df(rate_prediction, "rate_log_p05", default_value=rate_log_pred)
    rate_log_p95 = get_float_from_df(rate_prediction, "rate_log_p95", default_value=rate_log_pred)
    maintenance_count = get_int_from_df(maintenance_summary, "maintenance_count", default_value=0)
    total_ghg = get_float_from_df(lca_summary, "Total Emission", default_value=0.0)
    total_cost = get_float_from_df(lcca_summary, "Total Cost", default_value=0.0)

    col_1, col_2, col_3, col_4 = st.columns(4)
    col_1.metric("Mean rate", f"{rate_pred:.6f}")
    col_2.metric("Rate_Log P05-P95", f"{rate_log_p05:.3f}–{rate_log_p95:.3f}")
    col_3.metric("Total GHG mean", f"{total_ghg:,.0f} kg CO₂e")
    col_4.metric("Total cost mean", f"${total_cost:,.0f}")

    st.caption(f"Analysis mode: Single pavement design. Input mode: {input_mode}. Mean Rate_Log: {rate_log_pred:.6f}. Maintenance count: {maintenance_count}.")

    tab_1, tab_2, tab_3, tab_4, tab_5 = st.tabs(["IRI & M&R", "LCA", "LCCA", "Model and assumptions", "Download"])

    with tab_1:
        st.subheader("IRI progression")
        render_iri_chart(results["yearly_iri"])
        st.subheader("Yearly IRI table")
        st.dataframe(results["yearly_iri"], use_container_width=True)
        st.subheader("Maintenance summary")
        st.dataframe(results["maintenance_summary"], use_container_width=True)

    with tab_2:
        st.subheader("LCA probability distribution")
        render_distribution_histogram(results.get("lca_distribution"), "Total Emission", "Total life-cycle GHG distribution", "kg CO₂e", color="#2A9D8F")
        st.subheader("LCA contribution rate based on mean values")
        render_contribution_chart(results["lca_phase_contribution"], "LCA")
        st.subheader("LCA mean summary")
        st.dataframe(results["lca_summary"], use_container_width=True)
        st.subheader("LCA uncertainty summary")
        st.dataframe(results.get("lca_uncertainty_summary", pd.DataFrame()), use_container_width=True)
        st.subheader("LCA phase contribution")
        st.dataframe(results["lca_phase_contribution"], use_container_width=True)
        st.subheader("LCA layer-stage table")
        st.dataframe(results["lca_layer_stage"], use_container_width=True)
        st.subheader("LCA maintenance events")
        st.dataframe(results["lca_maintenance_events"], use_container_width=True)
        st.subheader("LCA EOL details")
        st.dataframe(results["lca_eol_details"], use_container_width=True)

    with tab_3:
        st.subheader("LCCA probability distribution")
        render_distribution_histogram(results.get("lcca_distribution"), "Total Cost", "Total life-cycle cost distribution", "USD PV", color="#E76F51")
        st.subheader("LCCA contribution rate based on mean values")
        render_contribution_chart(results["lcca_phase_contribution"], "LCCA")
        st.subheader("LCCA mean summary")
        st.dataframe(results["lcca_summary"], use_container_width=True)
        st.subheader("LCCA uncertainty summary")
        st.dataframe(results.get("lcca_uncertainty_summary", pd.DataFrame()), use_container_width=True)
        st.subheader("LCCA phase contribution")
        st.dataframe(results["lcca_phase_contribution"], use_container_width=True)
        st.subheader("LCCA layer-stage table")
        st.dataframe(results["lcca_layer_stage"], use_container_width=True)
        st.subheader("LCCA maintenance events")
        st.dataframe(results["lcca_maintenance_events"], use_container_width=True)
        st.subheader("LCCA EOL details")
        st.dataframe(results["lcca_eol_details"], use_container_width=True)

    with tab_4:
        st.subheader("Input parameters")
        st.dataframe(results["input_parameters"], use_container_width=True)
        st.subheader("Rate prediction")
        st.dataframe(results["rate_prediction"], use_container_width=True)
        st.subheader("BLL feature input")
        st.dataframe(results.get("bll_feature_input", pd.DataFrame()), use_container_width=True)
        st.subheader("Rate model metadata")
        st.dataframe(results["rate_model_metadata"], use_container_width=True)
        st.subheader("FUNC_CLASS mapping")
        st.dataframe(results["func_class_mapping"], use_container_width=True)
        st.subheader("Pavement type configuration")
        st.dataframe(results["pavement_type_config"], use_container_width=True)
        st.subheader("Parameter documentation")
        st.dataframe(results["parameter_documentation"], use_container_width=True)

    with tab_5:
        st.subheader("Download results")
        excel_bytes = build_excel_bytes(results)
        file_name = (
            f"PaveLIFE_{input_dict_current['pavement_family']}_"
            f"{input_dict_current['pavement_type']}_{input_dict_current['shrp_id']}.xlsx"
        )
        st.download_button(
            label="Download Excel report",
            data=excel_bytes,
            file_name=file_name,
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )


def render_comparison_results(comparison_items, input_mode):
    comparison_summary_df = build_comparison_summary(comparison_items)

    best_ghg_idx = comparison_summary_df["Total GHG, kg CO2e"].astype(float).idxmin()
    best_cost_idx = comparison_summary_df["Total cost PV, USD"].astype(float).idxmin()
    min_ghg_design = str(comparison_summary_df.loc[best_ghg_idx, "Design"])
    min_cost_design = str(comparison_summary_df.loc[best_cost_idx, "Design"])

    col_1, col_2, col_3, col_4 = st.columns(4)
    col_1.metric("Compared designs", f"{len(comparison_items)}")
    col_2.metric("Lowest GHG design", min_ghg_design)
    col_3.metric("Lowest cost design", min_cost_design)
    col_4.metric("Input mode", input_mode)

    st.caption("Analysis mode: Design comparison. Climate, traffic, functional class, IRI0, and analysis settings are shared across all compared designs.")

    tab_1, tab_2, tab_3, tab_4, tab_5 = st.tabs(["Comparison summary", "IRI & M&R", "LCA", "LCCA", "Download"])

    with tab_1:
        st.subheader("Design comparison summary")
        st.dataframe(comparison_summary_df, use_container_width=True)

    with tab_2:
        st.subheader("IRI progression comparison")
        render_comparison_iri_chart(comparison_items)
        st.subheader("Maintenance timeline")
        render_maintenance_timeline(comparison_items)
        with st.expander("Yearly IRI tables by design", expanded=False):
            for item in comparison_items:
                st.markdown(f"**{item['design_label']}**")
                st.dataframe(item["results"]["yearly_iri"], use_container_width=True)

    with tab_3:
        st.subheader("Total life-cycle GHG emissions")
        render_metric_comparison_bar(
            comparison_summary_df,
            "Total GHG, kg CO2e",
            "Total life-cycle GHG emissions",
            "kg CO₂e",
            lca_palette,
        )
        st.subheader("LCA contribution structure")
        render_comparison_contribution_stacked(comparison_items, "lca_phase_contribution", "LCA contribution rate by design")
        with st.expander("LCA tables by design", expanded=False):
            for item in comparison_items:
                st.markdown(f"**{item['design_label']}**")
                st.dataframe(item["results"]["lca_summary"], use_container_width=True)
                st.dataframe(item["results"]["lca_phase_contribution"], use_container_width=True)

    with tab_4:
        st.subheader("Total life-cycle cost")
        render_metric_comparison_bar(
            comparison_summary_df,
            "Total cost PV, USD",
            "Total life-cycle cost PV",
            "USD PV",
            lcca_palette,
        )
        st.subheader("LCCA contribution structure")
        render_comparison_contribution_stacked(comparison_items, "lcca_phase_contribution", "LCCA contribution rate by design")
        with st.expander("LCCA tables by design", expanded=False):
            for item in comparison_items:
                st.markdown(f"**{item['design_label']}**")
                st.dataframe(item["results"]["lcca_summary"], use_container_width=True)
                st.dataframe(item["results"]["lcca_phase_contribution"], use_container_width=True)

    with tab_5:
        st.subheader("Download comparison results")
        excel_bytes = build_comparison_excel_bytes(comparison_items, comparison_summary_df)
        st.download_button(
            label="Download comparison Excel report",
            data=excel_bytes,
            file_name="PaveLIFE_design_comparison.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )


st.markdown(
    """
    <div class="pavelife-hero">
        <h1>PaveLIFE-Pro Web</h1>
        <p>
        An interactive pavement LCA-LCCA tool integrating probabilistic BLL IRI deterioration-rate prediction,
        reliability-based maintenance simulation, life-cycle GHG accounting, life-cycle cost analysis,
        and multi-design comparison under shared climate, traffic, material, and probabilistic assumptions.
        </p>
        <span class="pavelife-pill">Single design</span>
        <span class="pavelife-pill">Design comparison</span>
        <span class="pavelife-pill">BLL IRI prediction</span>
        <span class="pavelife-pill">LCA</span>
        <span class="pavelife-pill">LCCA</span>
        <span class="pavelife-pill">Reliability-based M&R</span>
    </div>
    """,
    unsafe_allow_html=True,
)

analysis_mode, input_mode, common_input, design_inputs, analysis_settings, model_dir, run_button = build_sidebar_inputs()

if "pavelife_results_payload" not in st.session_state:
    st.session_state["pavelife_results_payload"] = None

if not run_button and st.session_state["pavelife_results_payload"] is None:
    st.info("Select an analysis mode, enter parameters in the sidebar, and click **Run PaveLIFE**.")
    st.stop()

if run_button:
    try:
        with st.spinner("Running PaveLIFE calculation..."):
            if analysis_mode == "Single pavement design":
                input_dict = build_input_dict(common_input, design_inputs[0], design_index=1)
                results = run_single_design(input_dict, analysis_settings, model_dir)
                st.session_state["pavelife_results_payload"] = {
                    "analysis_mode": analysis_mode,
                    "input_mode": input_mode,
                    "input_dict": input_dict,
                    "results": results,
                }
            else:
                comparison_items = run_design_comparison(common_input, design_inputs, analysis_settings, model_dir)
                st.session_state["pavelife_results_payload"] = {
                    "analysis_mode": analysis_mode,
                    "input_mode": input_mode,
                    "comparison_items": comparison_items,
                }
        st.success("PaveLIFE calculation completed.")

    except Exception as error:
        st.error("PaveLIFE calculation failed.")
        st.exception(error)
        st.stop()

payload = st.session_state["pavelife_results_payload"]

if payload["analysis_mode"] == "Single pavement design":
    render_single_results(
        results=payload["results"],
        input_dict_current=payload["input_dict"],
        input_mode=payload["input_mode"],
    )
else:
    render_comparison_results(
        comparison_items=payload["comparison_items"],
        input_mode=payload["input_mode"],
    )
