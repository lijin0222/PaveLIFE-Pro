# pavelife_core/pro_ppo.py
"""Experimental PPO maintenance-policy hook for PaveLIFE-Pro.

This module implements a lightweight project-level/section-level PPO entry point
inspired by the uploaded notebook. It is intentionally optional because PPO
training can be slow in an interactive Streamlit request and requires additional
packages (`gymnasium`, `stable-baselines3`).
"""

from __future__ import annotations

from typing import Dict, List, Sequence

import numpy as np
import pandas as pd

from pavelife_core.pro_iri import calculate_iri_drop, calculate_reliability_requirement, calculate_threshold


class PPOOptimizationNotAvailableError(RuntimeError):
    pass


def _import_ppo_dependencies():
    try:
        import gymnasium as gym
        from gymnasium import spaces
        from stable_baselines3 import PPO
        from stable_baselines3.common.env_checker import check_env
    except Exception as exc:  # pragma: no cover - optional dependency
        raise PPOOptimizationNotAvailableError(
            "PPO optimization requires gymnasium and stable-baselines3. Install with: "
            "pip install gymnasium stable-baselines3"
        ) from exc
    return gym, spaces, PPO, check_env


def _approximate_annual_usage_penalty(iri_value: float, iri0: float) -> float:
    """Small smooth proxy cost used only inside the PPO environment."""
    excess = max(float(iri_value) - float(iri0), 0.0)
    return excess * excess


def run_project_level_ppo_policy(
    section_row: pd.Series,
    rate_samples: Sequence[float],
    analysis_settings: Dict,
) -> List[int]:
    """Train a lightweight PPO policy and return forced M&R years.

    The life-cycle accounting is still performed by the main Pro runner. This
    PPO hook only proposes intervention years. If PPO dependencies are not
    installed, the caller receives a clear installation error.
    """
    gym, spaces, PPO, check_env = _import_ppo_dependencies()

    analysis_years = int(analysis_settings.get("analysis_years", 50))
    total_timesteps = int(analysis_settings.get("ppo_total_timesteps", 20000))
    seed = int(analysis_settings.get("ppo_seed", 42))

    class PavementMRPolicyEnv(gym.Env):
        metadata = {"render_modes": []}

        def __init__(self):
            super().__init__()
            self.iri0 = float(section_row["IRI0"])
            self.func_class = int(section_row["FUNC_CLASS"])
            self.threshold = calculate_threshold(self.func_class)
            self.required_reliability = calculate_reliability_requirement(self.func_class)
            self.rate_samples = np.asarray(rate_samples, dtype=np.float64)
            self.rate_mean = float(np.mean(self.rate_samples))
            self.action_space = spaces.Discrete(2)
            # year, iri, reliability, years_since_mr, maintenance_count
            self.observation_space = spaces.Box(low=0.0, high=10.0, shape=(5,), dtype=np.float32)
            self.reset(seed=seed)

        def _get_obs(self):
            return np.array([
                self.year / max(1, analysis_years),
                min(self.current_iri / 10.0, 1.0),
                self.current_reliability,
                min(self.years_since_mr / max(1, analysis_years), 1.0),
                min(self.maintenance_count / 10.0, 1.0),
            ], dtype=np.float32)

        def _update_reliability(self):
            iri_samples = self.cycle_start_iri_samples * np.exp(
                np.clip(self.rate_samples * float(self.years_since_mr), -50.0, 50.0)
            )
            self.current_iri = float(np.median(iri_samples))
            self.current_reliability = float(np.mean(iri_samples < self.threshold))
            return iri_samples

        def reset(self, seed=None, options=None):
            super().reset(seed=seed)
            self.year = 0
            self.years_since_mr = 0
            self.maintenance_count = 0
            self.current_iri = self.iri0
            self.current_reliability = 1.0
            self.cycle_start_iri_samples = np.full_like(self.rate_samples, self.iri0, dtype=np.float64)
            self.maintenance_years = []
            return self._get_obs(), {}

        def step(self, action):
            self.year += 1
            self.years_since_mr += 1
            iri_samples = self._update_reliability()

            do_mr = int(action) == 1
            # Enforce serviceability: if reliability is below requirement, M&R must occur.
            if self.current_reliability < self.required_reliability:
                do_mr = True

            reward = -_approximate_annual_usage_penalty(self.current_iri, self.iri0)
            if do_mr:
                self.maintenance_count += 1
                self.maintenance_years.append(self.year)
                # Proxy intervention penalty. Subsequent treatments are more disruptive.
                reward -= 1.0 + 0.25 * max(self.maintenance_count - 1, 0)
                drop = calculate_iri_drop(iri_samples)
                after = np.maximum(iri_samples - drop, self.iri0)
                self.cycle_start_iri_samples = after.copy()
                self.years_since_mr = 0
                self.current_iri = float(np.median(after))
                self.current_reliability = float(np.mean(after < self.threshold))

            terminated = self.year >= analysis_years
            truncated = False
            return self._get_obs(), float(reward), terminated, truncated, {}

    env = PavementMRPolicyEnv()
    # Avoid check_env for speed; uncomment during development if needed.
    model = PPO(
        "MlpPolicy",
        env,
        learning_rate=float(analysis_settings.get("ppo_learning_rate", 3e-4)),
        n_steps=int(analysis_settings.get("ppo_n_steps", 256)),
        batch_size=int(analysis_settings.get("ppo_batch_size", 128)),
        gamma=float(analysis_settings.get("ppo_gamma", 1.0)),
        verbose=0,
        seed=seed,
    )
    model.learn(total_timesteps=total_timesteps)

    obs, _ = env.reset(seed=seed)
    done = False
    while not done:
        action, _ = model.predict(obs, deterministic=True)
        obs, _, terminated, truncated, _ = env.step(action)
        done = bool(terminated or truncated)

    return list(env.maintenance_years)
